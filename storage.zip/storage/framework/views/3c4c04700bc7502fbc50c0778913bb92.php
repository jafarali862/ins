

<?php $__env->startSection('title', 'Odometer View'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="text-right">
            <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left"
                    aria-hidden="true"></i></button>
            <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner"
                    aria-hidden="true"></i></button>
            <a href="<?php echo e(route('odometer.list')); ?>" class="btn btn-primary mr-2 mb-2">
                <i class="fa fa-list" aria-hidden="true"></i>
            </a>
        </div>
        <h1 class="h3 mb-4 text-gray-800">Odometer Reading Details</h1>

        

        <div class="card shadow-lg border-0 rounded">
            <div class="card-body">
                <h5 class="card-title">Executive Name: <span class="text-primary"><?php echo e($record->user_name); ?></span></h5>
                <hr class="my-4">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <p class="card-text"><strong>Check In KM:</strong> <span
                                class="text-muted"><?php echo e($record->check_in_km); ?></span></p>
                        <p class="card-text"><strong>Check In Time:</strong> <span
                                class="text-muted"><?php echo e($record->check_in_time); ?></span></p>
                        <p class="card-text"><strong>Check In Date:</strong> <span
                                class="text-muted"><?php echo e($record->check_in_date); ?></span></p>
                        <p class="card-text"><strong>Check In Location:</strong> <span
                                class="text-muted"><?php echo e($record->check_in_latitude_and_longitude ?? 'N/A'); ?></span></p>
                    </div>
                    <div class="col-md-4">
                        <p class="card-text"><strong>Check Out KM:</strong> <span
                                class="text-muted"><?php echo e($record->check_out_km ?? 'N/A'); ?></span></p>
                        <p class="card-text"><strong>Check Out Time:</strong> <span
                                class="text-muted"><?php echo e($record->check_out_time ?? 'N/A'); ?></span></p>
                        <p class="card-text"><strong>Check Out Date:</strong> <span
                                class="text-muted"><?php echo e($record->check_out_date ?? 'N/A'); ?></span></p>
                        <p class="card-text"><strong>Check Out Location:</strong> <span
                                class="text-muted"><?php echo e($record->check_out_latitude_and_longitude ?? 'N/A'); ?></span></p>
                    </div>
                    <div class="col-md-4">
                        <p class="card-text"><strong>Total KM:</strong>
                            <?php
                                $totalKm = $record->check_out_km ? $record->check_out_km - $record->check_in_km : null;
                            ?>
                            <span class="text-muted <?php echo e($totalKm < 0 ? 'text-danger' : ''); ?>">
                                <?php echo e($totalKm !== null ? $totalKm : 'Check Out KM not recorded'); ?>

                            </span>
                            <?php if($totalKm < 0): ?>
                                <span class="badge badge-danger ml-2">Wrong</span>
                            <?php endif; ?>
                        </p>
                        <p class="card-text"><strong>Work Duration:</strong>
                            <?php
                                $checkInTime = \Carbon\Carbon::createFromFormat('h:i A', $record->check_in_time);

                                if ($record->check_out_time) {
                                    $checkOutTime = \Carbon\Carbon::createFromFormat('h:i A', $record->check_out_time);
                                    $duration = $checkOutTime->diff($checkInTime);
                                } else {
                                    $duration = null;
                                }
                            ?>

                            <?php if($duration): ?>
                                <span class="text-muted"><?php echo e($duration->format('%h hours %i minutes')); ?></span>
                            <?php else: ?>
                                <span class="text-muted">Check out time not recorded</span>
                            <?php endif; ?>

                        </p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <p class="card-text"><strong>Check In Image:</strong></p>
                        <?php if($record->check_in_image): ?>
                            <a href="<?php echo e(asset('storage/' . $record->check_in_image)); ?>" data-lightbox="checkin"
                                data-title="Check In Image">
                                <img src="<?php echo e(asset('storage/' . $record->check_in_image)); ?>" alt="Check In Image"
                                    class="img-fluid rounded shadow-sm"
                                    style="max-width: 300px; max-height: 200px; width: auto; height: auto;" />
                            </a>
                        <?php else: ?>
                            <span class="text-warning">N/A</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <p class="card-text"><strong>Check Out Image:</strong></p>
                        <?php if($record->check_out_image): ?>
                            <a href="<?php echo e(asset('storage/' . $record->check_out_image)); ?>" data-lightbox="checkout"
                                data-title="Check Out Image">
                                <img src="<?php echo e(asset('storage/' . $record->check_out_image)); ?>" alt="Check Out Image"
                                    class="img-fluid rounded shadow-sm"
                                    style="max-width: 300px; max-height: 200px; width: auto; height: auto;" />
                            </a>
                        <?php else: ?>
                            <span class="text-warning">N/A</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/odometer/view.blade.php ENDPATH**/ ?>