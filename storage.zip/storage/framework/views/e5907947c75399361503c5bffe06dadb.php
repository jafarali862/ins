
<?php $__env->startSection('title', 'Password Reset List'); ?>

<?php $__env->startSection('content'); ?>

     <div class="container-fluid">
    <div class="d-flex justify-content-end mb-3">
    <button class="btn btn-danger mr-2" onclick="window.history.back()" title="Back">
    <i class="fas fa-arrow-left"></i>
    </button>
    <button class="btn btn-warning mr-2" onclick="window.location.reload()" title="Reload">
    <i class="fas fa-sync-alt"></i>
    </button>
    <a href="<?php echo e(route('all.password.reset.request')); ?>" class="btn btn-primary">
    Show All Requests <i class="fas fa-list-ul"></i>
    </a>
    </div>

    <div class="card card-primary card-outline shadow-sm">
    <div class="card-header">
    <h3 class="card-title" style="font-size: 32px;">Pending Password Reset List</h3>
    </div>


    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <table id="passwordResetTable" class="table table-bordered table-striped text-center">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Request Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($request->user_name); ?></td>
                        <td><?php echo e($request->request_date); ?></td>
                        <td>
                            <a href="<?php echo e(route('password.reset.edit', $request->id)); ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables CSS/JS (if not already included in layout) -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#passwordResetTable').DataTable({
            "responsive": true,
            "autoWidth": false,
            "ordering": true,
            "pageLength": 10,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "language": {
                "search": "Search:",
                "lengthMenu": "Show _MENU_ entries",
                "zeroRecords": "No matching requests found",
                "info": "Showing _START_ to _END_ of _TOTAL_ requests",
                "infoEmpty": "No requests available",
                "infoFiltered": "(filtered from _MAX_ total entries)"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/password-reset/index.blade.php ENDPATH**/ ?>