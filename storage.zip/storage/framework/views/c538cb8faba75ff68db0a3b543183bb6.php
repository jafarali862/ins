<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        <!-- Optional: Any extra message or version info -->
        Powered by Niveosys
    </div>
    <strong>
        &copy; <?php echo e(date('Y')); ?> 
        <a href="https://niveosys.com" target="_blank">Niveosys Technologies Pvt Ltd</a>.
    </strong> All rights reserved.
</footer>
<?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/include/footer.blade.php ENDPATH**/ ?>