<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Data</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

   <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>

    <div class="container my-5">
        <!-- Company Details Header Section -->
        <div style="border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px;">
            <div style="text-align: center; margin-bottom: 10px;">
                <h1 style="font-size: 32px; color: #2C3E50; font-weight: bold;"><?php echo e($finalReport->insurance_com_name); ?></h1>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_email); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_address); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_contact_person); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_phone); ?></p>
            </div>
        </div>

  





        <div class="card mb-4">
    <div class="card-header bg-primary text-white text-center" style="text-align: center;">
        <h3>Customer Information</h3>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <tbody>
                <tr>
                    <th>Customer Name</th>
                    <td><?php echo e($finalReport->customer_name ?? 'N/A'); ?></td>
                    <th>Father's Name</th>
                    <td><?php echo e($finalReport->customer_father_name ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo e($finalReport->customer_phone ?? 'N/A'); ?></td>
                    <th>Emergency Contact</th>
                    <td><?php echo e($finalReport->customer_emergancy_contact_no ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($finalReport->customer_email ?? 'N/A'); ?></td>
                    <th>Present Address</th>
                    <td><?php echo e($finalReport->customer_present_address ?? 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Permanent Address</th>
                    <td><?php echo e($finalReport->customer_premanent_address ?? 'N/A'); ?></td>
                    <th>Policy No</th>
                    <td><?php echo e($finalReport->customer_policy_no ?? 'N/A'); ?></td>
                </tr>
                <tr>
    <th>Policy Start Date</th>
    <td>
        <?php echo e($finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A'); ?>

    </td>

    <th>Policy End Date</th>
    <td>
        <?php echo e($finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A'); ?>

    </td>
</tr>

                <tr>
                    <th>Crime Number</th>
                    <!-- <td colspan="3"><?php echo e($finalReport->customer_insurance_type ?? 'N/A'); ?></td> -->
                     <td><?php echo e($finalReport->crime_number ?? 'N/A'); ?></td>

                        <th>Police Station</th>
                    <!-- <td colspan="3"><?php echo e($finalReport->customer_insurance_type ?? 'N/A'); ?></td> -->
                     <td><?php echo e($finalReport->police_station ?? 'N/A'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>


           <div class="card mb-4">
    <div class="card-body">
        <?php
            $hasData = false;

            $fileExtensions = [
                'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp',
                'mp3', 'wav', 'ogg', 'aac',
                'mp4', 'avi', 'mov', 'mkv', 'webm',
                'pdf', 'doc', 'docx', 'xls', 'xlsx'
            ];
        ?>

        <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }

                if (!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
                    $hasData = true;
                }
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($hasData): ?>
            <div class="card-header bg-success text-white text-center">
                <h3>Garage Information</h3>
            </div>

            <table class="table table-bordered table-striped">
                <tbody>
                <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $column = $question->column_name;
                        $answer = $finalReport->$column ?? null;

                        $ext = '';
                        $decodedAnswer = $answer;

                        if (!is_null($answer) && is_string($answer)) {
                            $decoded = json_decode($answer, true);
                            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                                $decodedAnswer = implode(', ', $decoded);
                                $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                            } else {
                                $decodedAnswer = $answer;
                                $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                            }
                        }
                    ?>

                    <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                        <tr>
                            <th style="width: 30%;">
                                <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                            </th>
                            <td style="width: 70%; color: #7F8C8D;">
                                <?php echo e($decodedAnswer); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No garage related text information available.</p>
        <?php endif; ?>
    </div>
</div>


            <div class="card mb-4">
            <div class="card-header bg-info text-white text-center">
            <h3>Garage Uploaded Files</h3>
            </div>
            <div class="card-body">
            <div class="row">
            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            ?>

            <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;
            $images = [];

            if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
            } 
            else 
            {
            $images = [$answer];
            }
            }

            // Filter images by allowed extensions
            $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
            });
            ?>

            <?php if($validImages->isNotEmpty()): ?>
            <div class="col-md-12 mb-3">
            <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
            <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $imagePath = storage_path('app/public/' . $image);
            ?>

            <?php if(file_exists($imagePath)): ?>
            <div style="flex: 1 0 21%; box-sizing: border-box;">
            <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
            alt="Image"
            style="width: 70%; height: auto; border: 1px solid #ccc;">
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            </div>






             <div class="card mb-4">
            <div class="card-header bg-success text-white text-center">
            <h3>Spot Information</h3>
            </div>
            <div class="card-body">
            <?php $hasData = false; ?>

            <?php
            $hasData = false;

            // File extensions you want to exclude
            $fileExtensions = [
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
            'mp3', 'wav', 'ogg', 'aac', // audio
            'mp4', 'avi', 'mov', 'mkv', 'webm', // video
            'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
            ];
            ?>

            <table class="table table-bordered table-striped">
            <tbody>

            <!-- <?php $__currentLoopData = $validQuestions_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

            
                $ext = '';

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    $valueToCheck = is_array($decoded) ? ($decoded[0] ?? '') : $answer;
                    $ext = strtolower(pathinfo($valueToCheck, PATHINFO_EXTENSION));
                }
            ?>

            <?php if(!is_null($answer) && trim($answer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <?php $hasData = true; ?>
                <tr>
                    <th style="width: 30%;">
                        <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 70%; color: #7F8C8D;">
                        <?php echo e($answer); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->


            <?php $__currentLoopData = $validQuestions_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;

            $ext = '';
            $decodedAnswer = $answer;

            if (!is_null($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded); // Converts ["val"] to "val"
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
            } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
            }
            }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
            <?php $hasData = true; ?>
            <tr>
            <th style="width: 30%;">
            <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

            </th>
            <td style="width: 70%; color: #7F8C8D;">
            <?php echo e($decodedAnswer); ?>

            </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
            </table>

            <?php if(!$hasData): ?>
            <p>No spot-related information available.</p>
            <?php endif; ?>
            </div>
            </div>


            <div class="card mb-4">
            <div class="card-header bg-info text-white text-center">
            <h3>Spot Uploaded Files</h3>
            </div>
            <div class="card-body">
            <div class="row">
            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            ?>

            <?php $__currentLoopData = $validQuestions_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;
            $images = [];

            if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
            } 
            else 
            {
            $images = [$answer];
            }
            }

            // Filter images by allowed extensions
            $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
            });
            ?>

            <?php if($validImages->isNotEmpty()): ?>
            <div class="col-md-12 mb-3">
            <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
            <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $imagePath = storage_path('app/public/' . $image);
            ?>

            <?php if(file_exists($imagePath)): ?>
            <div style="flex: 1 0 21%; box-sizing: border-box;">
            <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
            alt="Image"
            style="width: 70%; height: auto; border: 1px solid #ccc;">
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            </div>





             <div class="card mb-4">
            <div class="card-header bg-success text-white text-center">
            <h3>Driver Information</h3>
            </div>
            <div class="card-body">
            <?php $hasData = false; ?>

            <?php
            $hasData = false;

            // File extensions you want to exclude
            $fileExtensions = [
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
            'mp3', 'wav', 'ogg', 'aac', // audio
            'mp4', 'avi', 'mov', 'mkv', 'webm', // video
            'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
            ];
            ?>

            <table class="table table-bordered table-striped">
            <tbody>


             <?php $__currentLoopData = $validQuestions_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;

            $ext = '';
            $decodedAnswer = $answer;

            if (!is_null($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded); // Converts ["val"] to "val"
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
            } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
            }
            }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
            <?php $hasData = true; ?>
            <tr>
            <th style="width: 30%;">
            <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

            </th>
            <td style="width: 70%; color: #7F8C8D;">
            <?php echo e($decodedAnswer); ?>

            </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
            </table>

            <?php if(!$hasData): ?>
            <p>No driver related information available.</p>
            <?php endif; ?>
            </div>
            </div>


            <div class="card mb-4">
            <div class="card-header bg-info text-white text-center">
            <h3>Driver Uploaded Files</h3>
            </div>
            <div class="card-body">
            <div class="row">
            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            ?>

            <?php $__currentLoopData = $validQuestions_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;
            $images = [];

            if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
            } 
            else 
            {
            $images = [$answer];
            }
            }

            // Filter images by allowed extensions
            $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
            });
            ?>

            <?php if($validImages->isNotEmpty()): ?>
            <div class="col-md-12 mb-3">
            <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
            <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $imagePath = storage_path('app/public/' . $image);
            ?>

            <?php if(file_exists($imagePath)): ?>
            <div style="flex: 1 0 21%; box-sizing: border-box;">
            <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
            alt="Image"
            style="width: 70%; height: auto; border: 1px solid #ccc;">
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            </div>




             <div class="card mb-4">
            <div class="card-header bg-success text-white text-center">
            <h3>Owner Information</h3>
            </div>
            <div class="card-body">
            <?php $hasData = false; ?>

            <?php
            $hasData = false;

            // File extensions you want to exclude
            $fileExtensions = [
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
            'mp3', 'wav', 'ogg', 'aac', // audio
            'mp4', 'avi', 'mov', 'mkv', 'webm', // video
            'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
            ];
            ?>

            <table class="table table-bordered table-striped">
            <tbody>

             <?php $__currentLoopData = $validQuestions_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;

            $ext = '';
            $decodedAnswer = $answer;

            if (!is_null($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded); // Converts ["val"] to "val"
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
            } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
            }
            }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
            <?php $hasData = true; ?>
            <tr>
            <th style="width: 30%;">
            <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

            </th>
            <td style="width: 70%; color: #7F8C8D;">
            <?php echo e($decodedAnswer); ?>

            </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            </tbody>
            </table>

            <?php if(!$hasData): ?>
            <p>No owner related information available.</p>
            <?php endif; ?>
            </div>
            </div>


            <div class="card mb-4">
            <div class="card-header bg-info text-white text-center">
            <h3>Owner Uploaded Files</h3>
            </div>
            <div class="card-body">
            <div class="row">
            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            ?>

            <?php $__currentLoopData = $validQuestions_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;
            $images = [];

            if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
            } 
            else 
            {
            $images = [$answer];
            }
            }

            // Filter images by allowed extensions
            $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
            });
            ?>

            <?php if($validImages->isNotEmpty()): ?>
            <div class="col-md-12 mb-3">
            <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
            <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $imagePath = storage_path('app/public/' . $image);
            ?>

            <?php if(file_exists($imagePath)): ?>
            <div style="flex: 1 0 21%; box-sizing: border-box;">
            <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
            alt="Image"
            style="width: 70%; height: auto; border: 1px solid #ccc;">
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            </div>








              <div class="card mb-4">
            <div class="card-header bg-success text-white text-center">
            <h3>Accident PersonData Information</h3>
            </div>
            <div class="card-body">
            <?php $hasData = false; ?>

            <?php
            $hasData = false;

            // File extensions you want to exclude
            $fileExtensions = [
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
            'mp3', 'wav', 'ogg', 'aac', // audio
            'mp4', 'avi', 'mov', 'mkv', 'webm', // video
            'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
            ];
            ?>

            <table class="table table-bordered table-striped">
            <tbody>

            
             <?php $__currentLoopData = $validQuestions_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;

            $ext = '';
            $decodedAnswer = $answer;

            if (!is_null($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded); // Converts ["val"] to "val"
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
            } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
            }
            }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
            <?php $hasData = true; ?>
            <tr>
            <th style="width: 30%;">
            <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

            </th>
            <td style="width: 70%; color: #7F8C8D;">
            <?php echo e($decodedAnswer); ?>

            </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            </table>

            <?php if(!$hasData): ?>
            <p>No owner related information available.</p>
            <?php endif; ?>
            </div>
            </div>


            <div class="card mb-4">
            <div class="card-header bg-info text-white text-center">
            <h3>Accident Persons Uploaded Files</h3>
            </div>
            <div class="card-body">
            <div class="row">
            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            ?>

            <?php $__currentLoopData = $validQuestions_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $column = $question->column_name;
            $answer = $finalReport->$column ?? null;
            $images = [];

            if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
            } 
            else 
            {
            $images = [$answer];
            }
            }

            // Filter images by allowed extensions
            $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
            });
            ?>

            <?php if($validImages->isNotEmpty()): ?>
            <div class="col-md-12 mb-3">
            <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
            <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
            $imagePath = storage_path('app/public/' . $image);
            ?>

            <?php if(file_exists($imagePath)): ?>
            <div style="flex: 1 0 21%; box-sizing: border-box;">
            <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
            alt="Image"
            style="width: 70%; height: auto; border: 1px solid #ccc;">
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            </div>




        <!-- Garage Information Section -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h3>Executive Information</h3>
            </div>
            <div class="card mb-4">
            <div class="card-body">
                 <div style="margin-bottom: 15px;">
                    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 150px;">Driver Representing Executive:</span>
                    <span style="font-size: 16px; color: #7F8C8D; display: inline-block;"><?php echo e($finalReport->driver_executive ?? 'N/A'); ?></span>
                 </div>
                 <div style="margin-bottom: 15px;">
                    <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Garage Representing Executive:</span>
                    <span style="font-size: 16px; color: #7F8C8D; display: inline-block;"><?php echo e($finalReport->garage_executive ?? 'N/A'); ?></span>
                </div>
                <div style="margin-bottom: 15px;">
                    <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Spot Representing Executive:</span>
                    <span style="font-size: 16px; color: #7F8C8D; display: inline-block;"><?php echo e($finalReport->spot_executive ?? 'N/A'); ?></span>
                </div>
                <div style="margin-bottom: 15px;">
                    <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Meeting Representing Executive:</span>
                    <span style="font-size: 16px; color: #7F8C8D; display: inline-block;"><?php echo e($finalReport->owner_executive ?? 'N/A'); ?></span>
                </div>
                <div style="margin-bottom: 15px;">
                    <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Accident Representing Executive:</span>
                    <span style="font-size: 16px; color: #7F8C8D; display: inline-block;"><?php echo e($finalReport->accident_executive ?? 'N/A'); ?></span>
                </div>
            </div>
        </div>
        </div>

        <!-- Images Section -->

        <!-- <div class="card mb-4">
        <div class="card-header bg-secondary text-white">
        <h3>Selected Images</h3>
        </div>
        <div class="card-body">

        <div style="display: flex; flex-wrap: wrap; justify-content: start; gap: 10px;">
        <?php if($finalReport->questions11): ?>
        <?php $__currentLoopData = json_decode($finalReport->questions11); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="flex: 1 0 21%; box-sizing: border-box; margin-bottom: 10px;">
        <?php if(file_exists(storage_path('app/public/' . $image))): ?>
        <img src="data:image/<?php echo e(pathinfo($image, PATHINFO_EXTENSION)); ?>;base64,<?php echo e(base64_encode(file_get_contents(storage_path('app/public/' . $image)))); ?>" 
        alt="Image"
        style="width: 100%; height: auto; border: 1px solid #ccc;">
        <?php else: ?>
        <p>Image not found: <?php echo e($image); ?></p>
        <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>    
        </div>
        </div>
        </div> -->

    </div>

    <!-- Bootstrap JS & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/pdf/pdf.blade.php ENDPATH**/ ?>