
<?php $__env->startSection('title', 'Edit Company'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-center text-primary font-weight-bold">Edit Questionnaire</h1>

    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card card-primary shadow-sm rounded-lg">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-white">Edit Questionnaire</h6>
                </div>
                <div class="card-body">
                    <div id="successMessage" class="alert alert-success" style="display: none;"></div>

                    <form action="<?php echo e(route('questions.update_question', $question->id)); ?>" method="POST" id="updateQuestionForm" novalidate>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="question">Question <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="question" name="question" value="<?php echo e(old('question', $question->question)); ?>" required>
                            <small id="question-error" class="text-danger"></small>
                        </div>

                        <div class="form-group">
                            <label for="input_type">Input Type <span class="text-danger">*</span></label>
                            <select class="form-control" id="input_type" name="input_type" required>
                                <?php $__currentLoopData = ['text', 'textarea', 'select', 'file', 'date']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>" <?php echo e(old('input_type', $question->input_type) == $type ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($type)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small id="input_type-error" class="text-danger"></small>
                        </div>

                        <div class="form-group">
                            <label for="data_category">Data Category <span class="text-danger">*</span></label>
                            <select class="form-control" id="data_category" name="data_category" required>
                                <?php $__currentLoopData = ['garage_data', 'spot_data', 'owner_data', 'driver_data', 'accident_person_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat); ?>" <?php echo e(old('data_category', $question->data_category) == $cat ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst(str_replace('_', ' ', $cat))); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small id="data_category-error" class="text-danger"></small>
                        </div>

                        <button type="submit" class="btn btn-success">Update</button>
                        <a href="<?php echo e(route('questions.index_question')); ?>" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#updateQuestionForm').on('submit', function(e) {
        e.preventDefault();
        $('.text-danger').text('');
        $('#successMessage').hide().text('');

        const form = $(this);
        const actionUrl = form.attr('action');

        $.ajax({
            url: actionUrl,
            type: 'POST',
            data: form.serialize(),
            success: function(response) {
            if (response.success) {
            // Show the message
            $('#successMessage').text(response.success).fadeIn();

            // Wait 3 seconds, then redirect
            setTimeout(function() {
            window.location.href = response.redirect_url;
            }, 3000);
            }
            },

            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(field, messages) {
                        $('#' + field + '-error').text(messages[0]);
                    });
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/company/edit_question.blade.php ENDPATH**/ ?>