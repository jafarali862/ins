
<?php $__env->startSection('title', 'Report Request Detail'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row align-items-center mb-3">
        <!-- Heading -->
        <div class="col-md-6">
<h3 class="mb-0">
    <strong>
        <span style="color:#007bff;">Report Details for</span>
        <span style="color:#28a745;"><?php echo e($report->customer_name); ?></span>
    </strong>
</h3>
        </div>

        <!-- Search Form -->
        <div class="col-md-6">
        <form action="" method="GET" class="row gx-2 justify-content-end">
        <div class="col-auto">
        <input type="text" name="search" placeholder="Search..." value="" class="form-control">
        </div>
        <div class="col-auto">
        <button type="submit" class="btn btn-primary">Search</button>
        </div>       
        </form>
        </div>
        </div>

      <!-- Action Buttons -->
        <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-danger mr-2" onclick="window.history.back()" title="Back">
        <i class="fas fa-arrow-left"></i>
        </button>
        <button class="btn btn-warning mr-2" onclick="window.location.reload()" title="Reload">
        <i class="fas fa-sync-alt"></i>
        </button>

        </div>


        <div class="card">
        <div class="card-header">
        <h5><strong>General Information</strong></h5>
        </div>
        <div class="card-body">
        <p><strong>Company Name:</strong> <?php echo e($report->company_name); ?></p>
        <p><strong>Investigation Date:</strong> <?php echo e(\Carbon\Carbon::parse($report->date)->format('d-m-Y')); ?></p>
        <p><strong>Type:</strong> <?php echo e($report->type); ?></p>
        </div>
        </div>

        <hr>


        <?php if($report->is_fake == 1): ?>

        <span class="badge bg-danger">Fake</span>

       
        <?php else: ?>
        <button type="button" class="btn btn-secondary" style="margin-bottom: 10px;float:right;" onclick="confirmFakeData()">Fake Data</button>

        <form id="fakeDataForm" method="POST" action="<?php echo e(route('insurance.fake.data')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="case_id" value="<?php echo e($report->case_id); ?>">

        </form>
        <?php endif; ?>



        <?php if(session('success')): ?>
        <div class="alert alert-success">
        <?php echo e(session('success')); ?>

        </div>
        <script>
        // Reload after 5 seconds
        setTimeout(function () {
            location.reload();
        }, 5000); // 5000 milliseconds = 5 seconds
        </script>
        <?php endif; ?>


        <?php if(session('error')): ?>
        <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>


<!-- Nav Tabs -->
<ul class="nav nav-tabs mt-4" id="dataTabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="garage-tab" data-toggle="tab" href="#garageData" role="tab" aria-controls="garageData" aria-selected="true">Garage Data</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="driver-tab" data-toggle="tab" href="#driverData" role="tab" aria-controls="driverData" aria-selected="false">Driver Data</a>
    </li>

     <li class="nav-item">
        <a class="nav-link" id="spot-tab" data-toggle="tab" href="#spotData" role="tab" aria-controls="spotData" aria-selected="false">Spot Data</a>
    </li>

     <li class="nav-item">
        <a class="nav-link" id="owner-tab" data-toggle="tab" href="#ownerData" role="tab" aria-controls="ownerData" aria-selected="false">Owner Data</a>
    </li>

      <li class="nav-item">
        <a class="nav-link" id="accident-tab" data-toggle="tab" href="#accidentData" role="tab" aria-controls="accidentData" aria-selected="false">Accident Person Data</a>
    </li>


</ul>

<!-- Tab Content Wrapper -->
<div class="tab-content" id="dataTabsContent">

    <!--  Garage Data Tab -->
    <div class="tab-pane fade show active" id="garageData" role="tabpanel" aria-labelledby="garage-tab">
        <h5 class="mt-4">Garage Data</h5>

        <?php if($report->garage_reassign_status == 1): ?>
    
        <!-- Re-Assign Button -->
                <button type="button" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="<?php echo e($report->id); ?>">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="<?php echo e(route('garage.re.assign')); ?>" method="POST" id="reassignForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?> (<?php echo e($user->place); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>


        <?php endif; ?>

        <?php if($report->garage_reassign_status == 0): ?>

        <span class="badge bg-warning text-dark">Pending</span>

        <?php endif; ?>

          <!-- <?php if($report->is_fake == 1): ?>

        <span class="badge bg-danger">Fake</span>

        <?php endif; ?> -->


      


        <div class="card p-3 mb-4">

            <form method="POST" action="<?php echo e(route('garage.text.update_new')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $garageQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    ?>

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2"><?php echo e($question->question); ?></strong>

                        <div class="row">
                            <?php $__currentLoopData = $garageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $garage->$columnName ?? 'N/A';
                                    $radioId = "garage_radio_{$columnName}_{$garage->id}";
                                    $wrapperId = "garage_fieldWrapper_{$columnName}_{$garage->id}";
                                ?>

            <div class="col-md-4 mb-2">

            <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>
            <div class="form-check mb-1">
            <input type="radio" class="form-check-input select-answer-radio-garage" name="selected_field[<?php echo e($columnName); ?>]"
            value="<?php echo e($garage->id); ?>" data-column="<?php echo e($columnName); ?>" data-value="<?php echo e($value); ?>"  data-case="<?php echo e($report->case_id); ?>" id="<?php echo e($radioId); ?>">
    
            Select this garage: 
            <!-- <br><small>[<?php echo e($garage->executive_name); ?>]</small> -->
            <!-- </label> -->
            </div>
            <?php endif; ?>


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="<?php echo e($columnName); ?>:<?php echo e($garage->id); ?>"
            id="<?php echo e($radioId); ?>"
            data-target="#<?php echo e($wrapperId); ?>">
                                     
            <label class="form-check-label" for="<?php echo e($radioId); ?>">

            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
            $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
            $filePath = 'storage/' . $value;
            ?>

            <?php if(in_array($extension, $imageExtensions) && file_exists(public_path($filePath))): ?>
            <img src="<?php echo e(asset($filePath)); ?>" alt="Image" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;">

            <?php elseif(in_array($extension, $audioExtensions) && file_exists(public_path($filePath))): ?>
            <audio controls style="display: block; margin-bottom: 5px;">
            <source src="<?php echo e(asset($filePath)); ?>" type="audio/<?php echo e($extension); ?>">
            Your browser does not support the audio element.
            </audio>





            <?php else: ?>
            <p>
            <?php if($inputType === 'select'): ?>
            <?php if($value == 1): ?>
            Yes
            <?php elseif($value == 0): ?>
            No
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            </p>
            <?php endif; ?>


            <br><small>
            <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>    
            [<?php echo e($garage->executive_name); ?>]
             <?php endif; ?>
           </small>
            </label>



        </div>

        <div class="d-none field-wrapper mt-2" id="<?php echo e($wrapperId); ?>">
        <?php if($inputType === 'textarea'): ?>
        <textarea name="field_value[<?php echo e($garage->id); ?>][<?php echo e($columnName); ?>]" class="form-control"><?php echo e($value); ?></textarea>
        <?php elseif($inputType === 'file'): ?>
        <?php if($value): ?>
            <!-- <p><img src="<?php echo e(asset('storage/' . $value)); ?>" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        <?php endif; ?>
        <input type="file" name="field_value[<?php echo e($garage->id); ?>][<?php echo e($columnName); ?>]" class="form-control">
        <?php elseif($inputType === 'select'): ?>
    <?php
        $otherSelected = $value === 'Other';
    ?>

    <select name="field_value[<?php echo e($garage->id); ?>][<?php echo e($columnName); ?>]"
            class="form-control select-trigger"
            data-id="<?php echo e($garage->id); ?>"
            data-column="<?php echo e($columnName); ?>">
        <option value="Yes" <?php echo e($value == 'Yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="No" <?php echo e($value == 'No' ? 'selected' : ''); ?>>No</option>
        <option value="Other" <?php echo e($value == 'Other' ? 'selected' : ''); ?>>Other</option>
    </select>

       <input type="text" 
       name="other_value[<?php echo e($garage->id); ?>][<?php echo e($columnName); ?>]"
       class="form-control mt-2 other-input"
       id="other_input_<?php echo e($garage->id); ?>_<?php echo e($columnName); ?>"
       placeholder="Please specify"
       value="<?php echo e(old("other_value.$garage->id.$columnName")); ?>"
       style="<?php echo e($value == 'Other' ? '' : 'display:none;'); ?>; width:850px;">


        <?php else: ?>
        <input type="<?php echo e($inputType); ?>" name="field_value[<?php echo e($garage->id); ?>][<?php echo e($columnName); ?>]" value="<?php echo e($value); ?>" class="form-control">
        <?php endif; ?>

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
        </div>
        </div>


    <!-- 🧍 Driver Data Tab -->
        <div class="tab-pane fade" id="driverData" role="tabpanel" aria-labelledby="driver-tab">
        <h5 class="mt-4">Driver Data</h5>

        <?php if($report->driver_reassign_status == 1): ?>
    
         <button type="button" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="<?php echo e($report->id); ?>">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="<?php echo e(route('driver.re.assign')); ?>" method="POST" id="reassignForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?> (<?php echo e($user->place); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        <?php endif; ?>

        <?php if($report->driver_reassign_status == 0): ?>
        <span class="badge bg-warning text-dark">Pending</span>
        <?php endif; ?>

        <div class="card p-3 mb-4">



          <form method="POST" action="<?php echo e(route('driver.text.update_new')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $driverQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    ?>

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2"><?php echo e($question->question); ?></strong>

                        <div class="row">
                            <?php $__currentLoopData = $driverData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $driver->$columnName ?? 'N/A';
                                    $radioId = "driver_radio_{$columnName}_{$driver->id}";
                                    $wrapperId = "driver_fieldWrapper_{$columnName}_{$driver->id}";
                                ?>

            <div class="col-md-4 mb-2">

            <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>
            <div class="form-check mb-1">
            <input type="radio" class="form-check-input select-answer-radio-driver" name="selected_field[<?php echo e($columnName); ?>]"
            value="<?php echo e($driver->id); ?>" data-column="<?php echo e($columnName); ?>" data-value="<?php echo e($value); ?>"  data-case="<?php echo e($report->case_id); ?>" id="<?php echo e($radioId); ?>">


            Select this driver: 

            </div>
            <?php endif; ?>


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="<?php echo e($columnName); ?>:<?php echo e($driver->id); ?>"
            id="<?php echo e($radioId); ?>"
            data-target="#<?php echo e($wrapperId); ?>">
                                     
            <label class="form-check-label" for="<?php echo e($radioId); ?>">

            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
            $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
            $filePath = 'storage/' . $value;
            ?>

            <?php if(in_array($extension, $imageExtensions) && file_exists(public_path($filePath))): ?>
            <img src="<?php echo e(asset($filePath)); ?>" alt="Image" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;">

            <?php elseif(in_array($extension, $audioExtensions) && file_exists(public_path($filePath))): ?>
            <audio controls style="display: block; margin-bottom: 5px;">
            <source src="<?php echo e(asset($filePath)); ?>" type="audio/<?php echo e($extension); ?>">
            Your browser does not support the audio element.
            </audio>

            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>

            <br><small>
              <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>    
            [<?php echo e($driver->executive_name); ?>]
            <?php endif; ?>
           </small>
            </label>



        </div>

        <div class="d-none field-wrapper mt-2" id="<?php echo e($wrapperId); ?>">
        <?php if($inputType === 'textarea'): ?>
        <textarea name="field_value[<?php echo e($driver->id); ?>][<?php echo e($columnName); ?>]" class="form-control"><?php echo e($value); ?></textarea>
        <?php elseif($inputType === 'file'): ?>
        <?php if($value): ?>
            <!-- <p><img src="<?php echo e(asset('storage/' . $value)); ?>" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        <?php endif; ?>
        <input type="file" name="field_value[<?php echo e($driver->id); ?>][<?php echo e($columnName); ?>]" class="form-control">
        <?php elseif($inputType === 'select'): ?>
    <?php
        $otherSelected = $value === 'Other';
    ?>

    <select name="field_value[<?php echo e($driver->id); ?>][<?php echo e($columnName); ?>]"
            class="form-control select-trigger"
            data-id="<?php echo e($driver->id); ?>"
            data-column="<?php echo e($columnName); ?>">
        <option value="Yes" <?php echo e($value == 'Yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="No" <?php echo e($value == 'No' ? 'selected' : ''); ?>>No</option>
        <option value="Other" <?php echo e($value == 'Other' ? 'selected' : ''); ?>>Other</option>
    </select>

       <input type="text" 
       name="other_value[<?php echo e($driver->id); ?>][<?php echo e($columnName); ?>]"
       class="form-control mt-2 other-input"
       id="other_input_<?php echo e($driver->id); ?>_<?php echo e($columnName); ?>"
       placeholder="Please specify"
       value="<?php echo e(old("other_value.$driver->id.$columnName")); ?>"
       style="<?php echo e($value == 'Other' ? '' : 'display:none;'); ?>; width:850px;">


        <?php else: ?>
        <input type="<?php echo e($inputType); ?>" name="field_value[<?php echo e($driver->id); ?>][<?php echo e($columnName); ?>]" value="<?php echo e($value); ?>" class="form-control">
        <?php endif; ?>

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>


        </div>
        </div>




         <!-- 🧍 Spot Data Tab -->
        <div class="tab-pane fade" id="spotData" role="tabpanel" aria-labelledby="spot-tab">
        <h5 class="mt-4">Spot Data</h5>

        <?php if($report->spot_reassign_status == 1): ?>


        <!-- <form action="<?php echo e(route('spot.re.assign')); ?>" method="POST" class="ajax-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($report->id); ?>">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

          <button type="button" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="<?php echo e($report->id); ?>">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="<?php echo e(route('spot.re.assign')); ?>" method="POST" id="reassignForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?> (<?php echo e($user->place); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>



        <?php endif; ?>

        <?php if($report->spot_reassign_status == 0): ?>
        <span class="badge bg-warning text-dark">Pending</span>
        <?php endif; ?>

        <div class="card p-3 mb-4">


           <form method="POST" action="<?php echo e(route('spot.text.update_new')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $spotQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    ?>

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2"><?php echo e($question->question); ?></strong>

                        <div class="row">
                            <?php $__currentLoopData = $spotData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $spot->$columnName ?? 'N/A';
                                    $radioId = "spot_radio_{$columnName}_{$spot->id}";
                                    $wrapperId = "spot_fieldWrapper_{$columnName}_{$spot->id}";
                                ?>

            <div class="col-md-4 mb-2">

          <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input select-answer-radio-spot" name="selected_field[<?php echo e($columnName); ?>]"
            value="<?php echo e($spot->id); ?>" data-column="<?php echo e($columnName); ?>" data-value="<?php echo e($value); ?>"  data-case="<?php echo e($report->case_id); ?>" id="<?php echo e($radioId); ?>">

            Select this spot: 
            </div>
            <?php endif; ?>


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="<?php echo e($columnName); ?>:<?php echo e($spot->id); ?>"
            id="<?php echo e($radioId); ?>"
            data-target="#<?php echo e($wrapperId); ?>">
                                     
            <label class="form-check-label" for="<?php echo e($radioId); ?>">

            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
            $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
            $filePath = 'storage/' . $value;
            ?>

            <?php if(in_array($extension, $imageExtensions) && file_exists(public_path($filePath))): ?>
            <img src="<?php echo e(asset($filePath)); ?>" alt="Image" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;">

            <?php elseif(in_array($extension, $audioExtensions) && file_exists(public_path($filePath))): ?>
            <audio controls style="display: block; margin-bottom: 5px;">
            <source src="<?php echo e(asset($filePath)); ?>" type="audio/<?php echo e($extension); ?>">
            Your browser does not support the audio element.
            </audio>




            <?php else: ?>
            <p>
            <?php if($inputType === 'select'): ?>
            <?php if($value == 1): ?>
            Yes
            <?php elseif($value == 0): ?>
            No
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            </p>
            <?php endif; ?>



            <br><small>
            <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>
            [<?php echo e($spot->executive_name); ?>]
             <?php endif; ?>
           </small>
            </label>



        </div>

        <div class="d-none field-wrapper mt-2" id="<?php echo e($wrapperId); ?>">
        <?php if($inputType === 'textarea'): ?>
        <textarea name="field_value[<?php echo e($spot->id); ?>][<?php echo e($columnName); ?>]" class="form-control"><?php echo e($value); ?></textarea>
        <?php elseif($inputType === 'file'): ?>
        <?php if($value): ?>
            <!-- <p><img src="<?php echo e(asset('storage/' . $value)); ?>" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        <?php endif; ?>
        <input type="file" name="field_value[<?php echo e($spot->id); ?>][<?php echo e($columnName); ?>]" class="form-control">
        <?php elseif($inputType === 'select'): ?>
    <?php
        $otherSelected = $value === 'Other';
    ?>

    <select name="field_value[<?php echo e($spot->id); ?>][<?php echo e($columnName); ?>]"
            class="form-control select-trigger"
            data-id="<?php echo e($spot->id); ?>"
            data-column="<?php echo e($columnName); ?>">
        <option value="Yes" <?php echo e($value == 'Yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="No" <?php echo e($value == 'No' ? 'selected' : ''); ?>>No</option>
        <option value="Other" <?php echo e($value == 'Other' ? 'selected' : ''); ?>>Other</option>
    </select>

       <input type="text" 
       name="other_value[<?php echo e($spot->id); ?>][<?php echo e($columnName); ?>]"
       class="form-control mt-2 other-input"
       id="other_input_<?php echo e($spot->id); ?>_<?php echo e($columnName); ?>"
       placeholder="Please specify"
       value="<?php echo e(old("other_value.$spot->id.$columnName")); ?>"
       style="<?php echo e($value == 'Other' ? '' : 'display:none;'); ?>; width:850px;">

        <?php else: ?>
        <input type="<?php echo e($inputType); ?>" name="field_value[<?php echo e($spot->id); ?>][<?php echo e($columnName); ?>]" value="<?php echo e($value); ?>" class="form-control">
        <?php endif; ?>

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>

        
        </div>
        </div>



        <!-- 🧍 Owner Data Tab -->
        <div class="tab-pane fade" id="ownerData" role="tabpanel" aria-labelledby="owner-tab">
        <h5 class="mt-4">Owner Data</h5>

        <?php if($report->owner_reassign_status == 1): ?>

        <!-- <form action="<?php echo e(route('owner.re.assign')); ?>" method="POST" class="ajax-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($report->id); ?>">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

                <button type="button" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="<?php echo e($report->id); ?>">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="<?php echo e(route('owner.re.assign')); ?>" method="POST" id="reassignForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?> (<?php echo e($user->place); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        <?php endif; ?>

        <?php if($report->owner_reassign_status == 0): ?>
        <span class="badge bg-warning text-dark">Pending</span>
        <?php endif; ?>

        <div class="card p-3 mb-4">



           <form method="POST" action="<?php echo e(route('owner.text.update_new')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $ownerQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    ?>

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2"><?php echo e($question->question); ?></strong>

                        <div class="row">
                            <?php $__currentLoopData = $ownerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $owner->$columnName ?? 'N/A';
                                    $radioId = "owner_radio_{$columnName}_{$owner->id}";
                                    $wrapperId = "owner_fieldWrapper_{$columnName}_{$owner->id}";
                                ?>

            <div class="col-md-4 mb-2">
              <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>
                <div class="form-check mb-1">
            <input type="radio" class="form-check-input select-answer-radio-owner" name="selected_field[<?php echo e($columnName); ?>]"
            value="<?php echo e($owner->id); ?>" data-column="<?php echo e($columnName); ?>" data-value="<?php echo e($value); ?>"  data-case="<?php echo e($report->case_id); ?>" id="<?php echo e($radioId); ?>">

            Select this owner: 
        
            </div>
            <?php endif; ?>


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="<?php echo e($columnName); ?>:<?php echo e($spot->id); ?>"
            id="<?php echo e($radioId); ?>"
            data-target="#<?php echo e($wrapperId); ?>">
                                     
            <label class="form-check-label" for="<?php echo e($radioId); ?>">

            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
            $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
            $filePath = 'storage/' . $value;
            ?>

            <?php if(in_array($extension, $imageExtensions) && file_exists(public_path($filePath))): ?>
            <img src="<?php echo e(asset($filePath)); ?>" alt="Image" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;">

            <?php elseif(in_array($extension, $audioExtensions) && file_exists(public_path($filePath))): ?>
            <audio controls style="display: block; margin-bottom: 5px;">
            <source src="<?php echo e(asset($filePath)); ?>" type="audio/<?php echo e($extension); ?>">
            Your browser does not support the audio element.
            </audio>

           <?php else: ?>
    <p>
        <?php if($inputType === 'select'): ?>
            <?php if($value == 1): ?>
                Yes
            <?php elseif($value == 0): ?>
                No
            <?php else: ?>
                <?php echo e($value); ?>

            <?php endif; ?>
        <?php else: ?>
            <?php echo e($value); ?>

        <?php endif; ?>
    </p>
<?php endif; ?>


            </p>

            <br><small>
               <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>    
            [<?php echo e($owner->executive_name); ?>]
            <?php endif; ?>
           </small>
            </label>



        </div>

      

<div class="field-wrapper mt-2" id="<?php echo e($wrapperId); ?>" style="display: none;">

        <?php if($inputType === 'textarea'): ?>
        <textarea name="field_value[<?php echo e($owner->id); ?>][<?php echo e($columnName); ?>]" class="form-control"><?php echo e($value); ?></textarea>
        <?php elseif($inputType === 'file'): ?>

        
        <?php if($value): ?>
            <!-- <p><img src="<?php echo e(asset('storage/' . $value)); ?>" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        <?php endif; ?>
        <input type="file" name="field_value[<?php echo e($owner->id); ?>][<?php echo e($columnName); ?>]" class="form-control fa">
        <?php elseif($inputType === 'select'): ?>
    <?php
        $otherSelected = $value === 'Other';
    ?>

    <select name="field_value[<?php echo e($owner->id); ?>][<?php echo e($columnName); ?>]"
            class="form-control select-trigger"
            data-id="<?php echo e($owner->id); ?>"
            data-column="<?php echo e($columnName); ?>">
        <option value="Yes" <?php echo e($value == 'Yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="No" <?php echo e($value == 'No' ? 'selected' : ''); ?>>No</option>
        <option value="Other" <?php echo e($value == 'Other' ? 'selected' : ''); ?>>Other</option>
    </select>

       <input type="text" 
       name="other_value[<?php echo e($owner->id); ?>][<?php echo e($columnName); ?>]"
       class="form-control mt-2 other-input"
       id="other_input_<?php echo e($owner->id); ?>_<?php echo e($columnName); ?>"
       placeholder="Please specify"
       value="<?php echo e(old("other_value.$owner->id.$columnName")); ?>"
       style="<?php echo e($value == 'Other' ? '' : 'display:none;'); ?>; width:850px;">

        <?php else: ?>
        <input type="<?php echo e($inputType); ?>" name="field_value[<?php echo e($owner->id); ?>][<?php echo e($columnName); ?>]" value="<?php echo e($value); ?>" class="form-control">
        <?php endif; ?>

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>

        </div>
        </div>






         <!-- 🧍 Accident Person Data Tab -->
        <div class="tab-pane fade" id="accidentData" role="tabpanel" aria-labelledby="accident-tab">
        <h5 class="mt-4">Accident Person Data</h5>

        <?php if($report->accident_person_reassign_status == 1): ?>


        <!-- <form action="<?php echo e(route('accident.person.re.assign')); ?>" method="POST" class="ajax-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($report->id); ?>">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

           <button type="button" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="<?php echo e($report->id); ?>">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="<?php echo e(route('accident.person.re.assign')); ?>" method="POST" id="reassignForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>">
                <?php echo e($user->name); ?> (<?php echo e($user->place); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        <?php endif; ?>

        <?php if($report->accident_person_reassign_status == 0): ?>
        <span class="badge bg-warning text-dark">Pending</span>
        <?php endif; ?>

        <div class="card p-3 mb-4">




          <form method="POST" action="<?php echo e(route('accident.text.update_new')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $accidentQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    ?>

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2"><?php echo e($question->question); ?></strong>

                        <div class="row">
                            <?php $__currentLoopData = $accidentPersonData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $value = $accident->$columnName ?? 'N/A';
                                    $radioId = "accident_radio_{$columnName}_{$accident->id}";
                                    $wrapperId = "accident_fieldWrapper_{$columnName}_{$accident->id}";
                                ?>

            <div class="col-md-4 mb-2">

                  <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>
                <div class="form-check mb-1">
            <input type="radio" class="form-check-input select-answer-radio-accident" name="selected_field[<?php echo e($columnName); ?>]"
            value="<?php echo e($accident->id); ?>" data-column="<?php echo e($columnName); ?>" data-value="<?php echo e($value); ?>"  data-case="<?php echo e($report->case_id); ?>" id="<?php echo e($radioId); ?>">


            Select this accident: 
    
            </div>
            <?php endif; ?>

            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="<?php echo e($columnName); ?>:<?php echo e($spot->id); ?>"
            id="<?php echo e($radioId); ?>"
            data-target="#<?php echo e($wrapperId); ?>">
                                     
            <label class="form-check-label" for="<?php echo e($radioId); ?>">

            <?php
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
            $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
            $filePath = 'storage/' . $value;
            ?>

            <?php if(in_array($extension, $imageExtensions) && file_exists(public_path($filePath))): ?>
            <img src="<?php echo e(asset($filePath)); ?>" alt="Image" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;">

            <?php elseif(in_array($extension, $audioExtensions) && file_exists(public_path($filePath))): ?>
            <audio controls style="display: block; margin-bottom: 5px;">
            <source src="<?php echo e(asset($filePath)); ?>" type="audio/<?php echo e($extension); ?>">
            Your browser does not support the audio element.
            </audio>

            <?php else: ?>
            <p>
            <?php if($inputType === 'select'): ?>
            <?php if($value == 1): ?>
            Yes
            <?php elseif($value == 0): ?>
            No
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            <?php else: ?>
            <?php echo e($value); ?>

            <?php endif; ?>
            </p>
            <?php endif; ?>

            <br><small>
               <?php if(!empty($value) && strtolower(trim($value)) !== 'n/a'): ?>    
             [<?php echo e($accident->executive_name); ?>]
              <?php endif; ?>
            </small>
            </label>



        </div>

        <div class="d-none field-wrapper mt-2" id="<?php echo e($wrapperId); ?>">
        <?php if($inputType === 'textarea'): ?>
        <textarea name="field_value[<?php echo e($accident->id); ?>][<?php echo e($columnName); ?>]" class="form-control"><?php echo e($value); ?></textarea>
        <?php elseif($inputType === 'file'): ?>
        <?php if($value): ?>
            <!-- <p><img src="<?php echo e(asset('storage/' . $value)); ?>" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        <?php endif; ?>
        <input type="file" name="field_value[<?php echo e($accident->id); ?>][<?php echo e($columnName); ?>]" class="form-control">
        <?php elseif($inputType === 'select'): ?>
    <?php
        $otherSelected = $value === 'Other';
    ?>

    <select name="field_value[<?php echo e($accident->id); ?>][<?php echo e($columnName); ?>]"
            class="form-control select-trigger"
            data-id="<?php echo e($accident->id); ?>"
            data-column="<?php echo e($columnName); ?>">
        <option value="Yes" <?php echo e($value == 'Yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="No" <?php echo e($value == 'No' ? 'selected' : ''); ?>>No</option>
        <option value="Other" <?php echo e($value == 'Other' ? 'selected' : ''); ?>>Other</option>
    </select>

       <input type="text" 
       name="other_value[<?php echo e($accident->id); ?>][<?php echo e($columnName); ?>]"
       class="form-control mt-2 other-input"
       id="other_input_<?php echo e($accident->id); ?>_<?php echo e($columnName); ?>"
       placeholder="Please specify"
       value="<?php echo e(old("other_value.$accident->id.$columnName")); ?>"
       style="<?php echo e($value == 'Other' ? '' : 'display:none;'); ?>; width:850px;">

        <?php else: ?>
        <input type="<?php echo e($inputType); ?>" name="field_value[<?php echo e($accident->id); ?>][<?php echo e($columnName); ?>]" value="<?php echo e($value); ?>" class="form-control">
        <?php endif; ?>

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>

        </div>
        </div>


</div>


    <hr>

    </div>
    </div>

    </div>



<style>
.form-check-input[type=radio] 
{
    border-color: black;
}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Lightbox2 CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet" />
<!-- Lightbox2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>


    <script>
        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true,
            'fadeDuration': 300
        });
    </script>


<script>

document.querySelectorAll('.toggle-edit').forEach(radio => {
  radio.addEventListener('change', () => {
    const target = document.querySelector(radio.dataset.target);
    if (target) target.style.display = 'block';
  });
});


    function confirmFakeData() {
        if (confirm("Are you sure  want to mark this section as fake data?")) {
            document.getElementById('fakeDataForm').submit();
        }
    }



    document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.select-trigger').forEach(function (select) {
    select.addEventListener('change', function () {
    const garageId = this.dataset.id;
    const column = this.dataset.column;
    const input = document.getElementById(`other_input_${garageId}_${column}`);

    if (this.value === 'Other') {
        input.style.display = 'block';
    } else {
        input.style.display = 'none';
        input.value = ''; // Optional: clear text if not Other
    }
    });
    });
    });

 
    document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });

</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const radios = document.querySelectorAll('.toggle-edit');
        const wrappers = document.querySelectorAll('.field-wrapper');
        const submitBtn = document.getElementById('submitButtonWrapper');

        radios.forEach(radio => {
            radio.addEventListener('change', function () {
                // Hide all inputs
                wrappers.forEach(w => w.classList.add('d-none'));

                // Show the matching one
                const targetId = this.getAttribute('data-target');
                const targetWrapper = document.querySelector(targetId);
                if (targetWrapper) {
                    targetWrapper.classList.remove('d-none');
                }

                // Show submit button
                submitBtn.classList.remove('d-none');
            });
        });
    });
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    // ===== Gate Entry Radios =====
    const gateRadios = document.querySelectorAll('.toggle-gate');
    const gateInputs = document.querySelectorAll('.garage-input-gate');
    const gateButton = document.getElementById('updateGateButtonWrapper');

    gateRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            gateInputs.forEach(input => input.classList.add('d-none'));
            const input = document.getElementById(this.dataset.inputId);
            if (input) input.classList.remove('d-none');
            if (gateButton) gateButton.classList.remove('d-none');
        });
    });

    // ===== Garage Job Card Radios =====
    const jobRadios = document.querySelectorAll('.toggle-job');
    const jobInputs = document.querySelectorAll('.garage-input-job');
    const jobButton = document.getElementById('updateJobButtonWrapper');

    jobRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            jobInputs.forEach(input => input.classList.add('d-none'));
            const input = document.getElementById(this.dataset.inputId);
            if (input) input.classList.remove('d-none');
            if (jobButton) jobButton.classList.remove('d-none');
        });
    });

    // ===== Fitness Particular Radios =====
    const fitnessRadios = document.querySelectorAll('.toggle-fitness');
    const fitnessSelects = document.querySelectorAll('.garage-select-fitness');
    const fitnessButton = document.getElementById('fitnessButton');

    fitnessRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            fitnessSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`fitnessSelect${radio.id.replace('fitnessCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (fitnessButton) fitnessButton.classList.remove('d-none');
        });
    });

    const permitRadios = document.querySelectorAll('.toggle-permit');
    const permitSelects = document.querySelectorAll('.garage-select-permit');
    const permitButton = document.getElementById('permitButton');

    permitRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            permitSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`permitSelect${radio.id.replace('permitCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (permitButton) permitButton.classList.remove('d-none');
        });
    });

    const particularRadios = document.querySelectorAll('.toggle-particular');
    const particularSelects = document.querySelectorAll('.garage-select-particular');
    const particularButton = document.getElementById('particularButton');

    particularRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            particularSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`particularSelect${radio.id.replace('particularCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (particularButton) particularButton.classList.remove('d-none');
        });
    });


    const motorRadios = document.querySelectorAll('.toggle-motor');
    const motorSelects = document.querySelectorAll('.garage-select-motor');
    const motorButton = document.getElementById('motorButton');

    motorRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            motorSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`motorSelect${radio.id.replace('motorCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (motorButton) motorButton.classList.remove('d-none');
        });
    });


});
</script>


<script>
    $(document).ready(function() {
        $('.ajax-form').on('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            var form = $(this);
            var url = form.attr('action');
            var formData = form.serialize(); // Serialize the form data

            $.ajax({
                type: 'POST',
                url: url,
                data: formData,
                success: function(response) {
                    // Handle success (show message, update UI, etc.)
                    alert('Re-Assigned successfully!');
                },
                error: function(xhr, status, error) {
                    // Handle error
                    alert('An error occurred: ' + error);
                }
            });
        });
    });
</script>

<script>
    function editFieldDriver(id) {
        const form = document.getElementById('edit-form' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldGarage(id) {
        const form = document.getElementById('edit-form-garage' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldSpot(id) {
        const form = document.getElementById('edit-form-spot' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldOwner(id) {
        const form = document.getElementById('edit-form-owner' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldAccident(id) {
        const form = document.getElementById('edit-form-accident' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    //GARAGE

    
//     $('input.select-answer-radio').on('change', function() {
//     const columnName = $(this).data('column');
//     const value = $(this).data('value');
//     const caseId = $(this).data('case');

//     if ($(this).prop('checked')) {
//         $.ajax({
//             url: "<?php echo e(route('garage.save.selected')); ?>",
//             method: 'POST',
//             data: {
//                 column_name: columnName,
//                 value: value,
//                 case_id: caseId,
//                 _token: '<?php echo e(csrf_token()); ?>'
//             },
//             success: function(response) {
//                 console.log('Answer updated:', response.data.message);
//             },
//             error: function(xhr, status, error) {
//                 alert('Error updating answer: ' + error);
//             }
//         });
//     }
// });


$('input.select-answer-radio-garage').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');

    const isConfirmed = confirm('Are you sure you want to proceed to report with this garage?');

    if (!isConfirmed) {
        // Uncheck the radio if user cancels
        $(this).prop('checked', false);
        return;
    }

    // User confirmed; proceed with AJAX call
    $.ajax({
        url: "<?php echo e(route('garage.save.selected')); ?>",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            console.log('Answer updated:', response.data.message);

            // Call your "report" function here if needed:
            // submitReportFunction(); or redirect, etc.
        },
        error: function (xhr, status, error) {
            alert('Error updating answer: ' + error);
        }
    });
});



$('input.select-answer-radio-driver').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');

    const isConfirmed = confirm('Are you sure you want to proceed to report with this driver?');

    if (!isConfirmed) {
        // Uncheck the radio if user cancels
        $(this).prop('checked', false);
        return;
    }

    // User confirmed; proceed with AJAX call
    $.ajax({
        url: "<?php echo e(route('driver.save.selected')); ?>",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            console.log('Answer updated:', response.data.message);

            // Call your "report" function here if needed:
            // submitReportFunction(); or redirect, etc.
        },
        error: function (xhr, status, error) {
            alert('Error updating answer: ' + error);
        }
    });
});



$('input.select-answer-radio-spot').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');

    const isConfirmed = confirm('Are you sure you want to proceed to report with this spot?');

    if (!isConfirmed) {
        // Uncheck the radio if user cancels
        $(this).prop('checked', false);
        return;
    }

    // User confirmed; proceed with AJAX call
    $.ajax({
        url: "<?php echo e(route('spot.save.selected')); ?>",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            console.log('Answer updated:', response.data.message);

            // Call your "report" function here if needed:
            // submitReportFunction(); or redirect, etc.
        },
        error: function (xhr, status, error) {
            alert('Error updating answer: ' + error);
        }
    });
});


$('input.select-answer-radio-owner').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');

    const isConfirmed = confirm('Are you sure you want to proceed to report with this owner?');

    if (!isConfirmed) {
        // Uncheck the radio if user cancels
        $(this).prop('checked', false);
        return;
    }

    // User confirmed; proceed with AJAX call
    $.ajax({
        url: "<?php echo e(route('owner.save.selected')); ?>",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            console.log('Answer updated:', response.data.message);

            // Call your "report" function here if needed:
            // submitReportFunction(); or redirect, etc.
        },
        error: function (xhr, status, error) {
            alert('Error updating answer: ' + error);
        }
    });
});



$('input.select-answer-radio-accident').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');

    const isConfirmed = confirm('Are you sure you want to proceed to report with this accident?');

    if (!isConfirmed) {
        // Uncheck the radio if user cancels
        $(this).prop('checked', false);
        return;
    }

    // User confirmed; proceed with AJAX call
    $.ajax({
        url: "<?php echo e(route('accident.save.selected')); ?>",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            console.log('Answer updated:', response.data.message);

            // Call your "report" function here if needed:
            // submitReportFunction(); or redirect, etc.
        },
        error: function (xhr, status, error) {
            alert('Error updating answer: ' + error);
        }
    });
});



   


    $('input[type="checkbox"][id^="gateImage"], input[type="checkbox"][id^="jobCardImage"], input[type="checkbox"][id^="vehicleImage"], input[type="checkbox"][id^="towVehicleReport"]').on('change', function() {

        // var selectedImages = collectSelectedImages();  
        var value = $(this).attr('id');
        var parts = value.split('-');

        var garageId = parts[1];
        var caseId = parts[3];
        var selectedImages = collectSelectedGarageImages(garageId, caseId);

        if (selectedImages.length > 0) {

            sendSelectedGarageImages(selectedImages, garageId, caseId);
        }
    });


    function collectSelectedGarageImages(garageId, caseId) {
        var selectedImages = [];
        $('input[type="checkbox"]:checked').each(function() {

            selectedImages.push($(this).val());

        });

        return selectedImages;
    }


    function sendSelectedGarageImages(selectedImages, garageId, caseId) {
        $.ajax({
            url: '<?php echo e(route("garage.save.selected.images")); ?>',
            method: 'POST',
            data: {
                garage_id: garageId,
                case_id: caseId,
                selected_garage_images: selectedImages,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Selected images saved successfully!');
                } else {
                    alert('Failed to save selected images.');
                }
            },
            error: function(xhr, status, error) {

                alert('Warining: ' + 'Please select Garage Section Data First');
            }
        });
    }

    //Driver

    $('input[type="radio"][id^="selectDriver"]').on('change', function() {
        var value = $(this).val();
        var parts = value.split('-');
        var driverId = parts[0];
        var caseId = parts[1];
        var isChecked = $(this).prop('checked');
        console.log('Checkbox clicked for driver ID:', driverId);

        if (isChecked) {
            postSelectedDriver(driverId, caseId);
        }
    });


    function postSelectedDriver(driverId, caseId) {
        $.ajax({
            url: "<?php echo e(route('driver.save.selected')); ?>",
            method: 'POST',
            data: {
                driver_id: driverId,
                case_id: caseId,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                console.log(response.data.message);
                if (response.data.status === 200) {
                    console.log('Driver ID ' + driverId + ' selected successfully!');
                } else {
                    alert('Failed to select the driver.');
                }
            },
            error: function(xhr, status, error) {
                alert('Error: ' + error);
            }
        });
    }


    $('input[type="checkbox"][id^="rationCardImage"], input[type="checkbox"][id^="vehiclePermitImage"], input[type="checkbox"][id^="assetPicImage"], input[type="checkbox"][id^="driverImage"], input[type="checkbox"][id^="driverLicImage"], input[type="checkbox"][id^="driverRcImage"], input[type="checkbox"][id^="driverAadharImage"], input[type="checkbox"][id^="coDriverAadharImage"], input[type="checkbox"][id^="coPassengerDriverAadharImage"]').on('change', function() {

        var value = $(this).attr('id');
        var parts = value.split('-');
        var driverId = parts[1];
        var caseId = parts[3];
        var selectedImages = collectSelectedDriverImages(driverId, caseId);
        if (selectedImages.length > 0) {
            sendSelectedDriverImages(selectedImages, driverId, caseId);
        }
    });


    function collectSelectedDriverImages(driverId, caseId) {
        var selectedImages = [];
        $('input[type="checkbox"]:checked').each(function() {

            selectedImages.push($(this).val());

        });

        return selectedImages;
    }


    function sendSelectedDriverImages(selectedImages, driverId, caseId) {
        $.ajax({
            url: '<?php echo e(route("driver.save.selected.images")); ?>',
            method: 'POST',
            data: {
                driver_id: driverId,
                case_id: caseId,
                selected_driver_images: selectedImages,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                console.log(response.data.message);
                if (response.data.status === 200) {
                    console.log('Selected images saved successfully!');
                } else {
                    alert('Failed to save selected images.');
                }
            },
            error: function(xhr, status, error) {
                alert('Warining: ' + 'Please select Driver Section Data First');
            }
        });
    }

    //SPOT

    $('input[type="radio"][id^="selectSpot"]').on('change', function() {
        var value = $(this).val();
        var parts = value.split('-');
        var spotId = parts[0];
        var caseId = parts[1];
        var isChecked = $(this).prop('checked');
        console.log('Checkbox clicked for driver ID:', spotId);

        if (isChecked) {
            postSelectedSpot(spotId, caseId);
        }
    });


    function postSelectedSpot(spotId, caseId) {
        $.ajax({
            url: "<?php echo e(route('spot.save.selected')); ?>",
            method: 'POST',
            data: {
                spot_id: spotId,
                case_id: caseId,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                console.log(response.data.message);
                if (response.data.status === 200) {
                    console.log('Spot ID ' + spotId + ' selected successfully!');
                } else {
                    alert('Failed to select the Spot.');
                }
            },
            error: function(xhr, status, error) {
                alert('Warining: ' + 'Please select Spot Section Data First');
            }
        });
    }


    $('input[type="checkbox"][id^="spotImage"]').on('change', function() {

        var value = $(this).attr('id');
        var parts = value.split('-');
        var spotId = parts[1];
        var caseId = parts[3];
        var selectedImages = collectSelectedSpotImages(spotId, caseId);
        if (selectedImages.length > 0) {
            sendSelectedSpotImages(selectedImages, spotId, caseId);
        }
    });


    function collectSelectedSpotImages(spotId, caseId) {
        var selectedImages = [];

        $('input[type="checkbox"]:checked').each(function() {

            selectedImages.push($(this).val());

        });

        return selectedImages;
    }


    function sendSelectedSpotImages(selectedImages, spotId, caseId) {
        $.ajax({
            url: '<?php echo e(route("spot.save.selected.images")); ?>',
            method: 'POST',
            data: {
                spot_id: spotId,
                case_id: caseId,
                selected_spot_images: selectedImages,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Selected images saved successfully!');
                } else {
                    alert('Warining: ' + 'Please select Spot Section Data First');
                }
            },
            error: function(xhr, status, error) {
                alert('Warining: ' + 'Please select Spot Section Data First');
            }
        });
    }


    //OWNER

    $('input[type="radio"][id^="selectOwner"]').on('change', function() {
        var value = $(this).val();
        var parts = value.split('-');
        var ownerId = parts[0];
        var caseId = parts[1];
        var isChecked = $(this).prop('checked');
        console.log('Checkbox clicked for Owner ID:', ownerId);

        if (isChecked) {
            postSelectedOwner(ownerId, caseId);
        }
    });


    function postSelectedOwner(ownerId, caseId) {
        $.ajax({
            url: "<?php echo e(route('owner.save.selected')); ?>",
            method: 'POST',
            data: {
                owner_id: ownerId,
                case_id: caseId,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Owner ID ' + ownerId + ' selected successfully!');
                } else {
                    alert('Failed to select the owner.');
                }
            },
            error: function(xhr, status, error) {
                alert('Error: ' + error);
            }
        });
    }


    $('input[type="checkbox"][id^="ownerStatmentImage"],input[type="checkbox"][id^="ownerAadharImage"],input[type="checkbox"][id^="ownerRationImage"],input[type="checkbox"][id^="ownerDlImage"]').on('change', function() {

        var value = $(this).attr('id');
        var parts = value.split('-');
        var ownerId = parts[1];
        var caseId = parts[3];
        var selectedImages = collectSelectedOwnerImages();
        if (selectedImages.length > 0) {
            sendSelectedOwnerImages(selectedImages, ownerId, caseId);
        }
    });


    function collectSelectedOwnerImages() {
        var selectedImages = [];

        $('input[type="checkbox"]:checked').each(function() {

            selectedImages.push($(this).val());

        });

        return selectedImages;
    }


    function sendSelectedOwnerImages(selectedImages, ownerId, caseId) {
        $.ajax({
            url: '<?php echo e(route("owner.save.selected.images")); ?>',
            method: 'POST',
            data: {
                owner_id: ownerId,
                case_id: caseId,
                selected_owner_images: selectedImages,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Selected images saved successfully!');
                } else {
                    alert('Failed to save selected images.');
                }
            },
            error: function(xhr, status, error) {
                alert('Warining: ' + 'Please select Owner Section Data First');
            }
        });
    }


    //ACCIDENT

    $('input[type="radio"][id^="selectAccident"]').on('change', function() {
        var value = $(this).val();
        var parts = value.split('-');
        var accidentId = parts[0];
        var caseId = parts[1];
        var isChecked = $(this).prop('checked');
        console.log('Checkbox clicked for Accident ID:', accidentId);

        if (isChecked) {
            postSelectedAccident(accidentId, caseId);
        }
    });


    function postSelectedAccident(accidentId, caseId) {
        $.ajax({
            url: "<?php echo e(route('accident.save.selected')); ?>",
            method: 'POST',
            data: {
                accident_id: accidentId,
                case_id: caseId,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Accident ID ' + accidentId + ' selected successfully!');
                } else {
                    alert('Failed to select the Accident.');
                }
            },
            error: function(xhr, status, error) {
                alert('Error: ' + error);
            }
        });
    }


    $('input[type="checkbox"][id^="accidentPersonImage"],input[type="checkbox"][id^="accidentRationImage"],input[type="checkbox"][id^="accidentAadharImage"],input[type="checkbox"][id^="accidentStatmentImage"]').on('change', function() {

        var value = $(this).attr('id');
        var parts = value.split('-');
        var accidentId = parts[1];
        var caseId = parts[3];
        var selectedImages = collectSelectedAccidentImages();
        if (selectedImages.length > 0) {
            sendSelectedAccidentImages(selectedImages, accidentId, caseId);
        }
    });


    function collectSelectedAccidentImages() {
        var selectedImages = [];

        $('input[type="checkbox"]:checked').each(function() {

            selectedImages.push($(this).val());

        });

        return selectedImages;
    }


    function sendSelectedAccidentImages(selectedImages, accidentId, caseId) {
        $.ajax({
            url: '<?php echo e(route("accident.save.selected.images")); ?>',
            method: 'POST',
            data: {
                accident_id: accidentId,
                case_id: caseId,
                selected_accident_images: selectedImages,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {

                if (response.data.status === 200) {
                    console.log('Selected images saved successfully!');
                } else {
                    alert('Failed to save selected images.');
                }
            },
            error: function(xhr, status, error) {
                alert('Warining: ' + 'Please select Accident Section Data First');
            }
        });
    }
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/report/view.blade.php ENDPATH**/ ?>