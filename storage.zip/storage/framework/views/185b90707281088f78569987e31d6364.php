
<?php $__env->startSection('title', 'User List'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="d-flex justify-content-end mb-3">
    <a href="javascript:history.back()" class="btn btn-danger mr-2">
    <i class="fas fa-arrow-left"></i>
    </a>
    <a href="<?php echo e(url()->current()); ?>" class="btn btn-warning mr-2">
    <i class="fas fa-sync-alt"></i>
    </a>
    <?php if(count($logos) == 0): ?>
    <a href="<?php echo e(route('logo')); ?>" class="btn btn-primary">
    <i class="fas fa-user-plus"></i> Add Company Info
    </a>
    <?php endif; ?>

    </div>

    <div class="card card-primary card-outline shadow-sm">
    <div class="card-header">
    <h3 class="card-title" style="font-size: 32px;">Company Info List</h3>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
    <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="companyInfoTable" class="table table-bordered table-striped text-center">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Place</th>
                            <th>Logo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($logo->name); ?></td>
                            <td><?php echo e($logo->email); ?></td>
                            <td><?php echo e($logo->phone); ?></td>
                            <td><?php echo e($logo->place); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $logo->logo)); ?>" alt="Company Logo"
                                    class="img-fluid" style="max-width: 100px;">
                            </td>
                            <td>
                                <a href="<?php echo e(route('logo.edit', $logo->id)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables CSS & JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#companyInfoTable').DataTable({
            "responsive": true,
            "autoWidth": false,
            "ordering": true,
            "pageLength": 10,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "language": {
                "search": "Search:",
                "zeroRecords": "No matching records found",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "No records available",
                "infoFiltered": "(filtered from _MAX_ total records)"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/logo/index.blade.php ENDPATH**/ ?>