<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Data</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

   <style>

  /* General table styles (you may already have this) */
table.custom-table {
    width: 100%;
    border-collapse: collapse;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* ===== Styling ONLY the table headers ===== */
/* table.custom-table thead th {
    background-color: #4b0082;  
    color: #ffffff;           
    padding: 14px 18px;
    text-align: left;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    border: 1px solid #ddd;
} */

/* ===== Styling the body cells normally ===== */
table.custom-table tbody td {
    background-color: #f9f9f9;
    color: #333;
    padding: 12px 18px;
    border: 1px solid #e2e2e2;
}

 table 
        {
            border-collapse: collapse;
            width: 100%;
        }

        /* th,
        td 
        {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        } */
        .custom-th {
        background-color: #007bff; /* Bootstrap primary */
        color: white;
        font-weight: bold;
        text-transform: capitalize;
        padding: 10px;
    }

    .custom-td {
        background-color: #f8f9fa;
        color: #343a40;
        padding: 10px;
    }
    </style>

    <div class="container my-5"> 
        <div style="border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px;">
            <div style="text-align: center; margin-bottom: 10px;">
                <h1 style="font-size: 32px; color: #178bffff; font-weight: bold;"><?php echo e($finalReport->insurance_com_name); ?></h1>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_email); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_address); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_contact_person); ?></p>
                <p style="font-size: 18px; color: #7F8C8D;"><?php echo e($finalReport->insurance_com_phone); ?></p>
            </div>
        </div>


        <div class="card mb-4">
        <div class="card-header bg-primary text-white text-center" style="text-align: center;">
        <h3 style="color: #7d18b8; font-weight: bold;">Customer Information</h3>
        </div>

            <div class="custom-table-container">

                <table class="custom-table">
                <thead>

                <tr>
                <th style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Customer Name</th>
                <th style="font-weight: normal;"><?php echo e($finalReport->customer_name ?? 'N/A'); ?></th>
                <th style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Father's Name</th>
                <th style="font-weight: normal;"><?php echo e($finalReport->customer_father_name ?? 'N/A'); ?></th>
                </tr>
                </thead>

                <tbody>
                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Phone</td>
                <td style="font-weight: normal;"><?php echo e($finalReport->customer_phone ?? 'N/A'); ?></td>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Emergency Contact</td>

                <td style="font-weight: normal;"><?php echo e($finalReport->customer_emergancy_contact_no ?? 'N/A'); ?></td>
                </tr>
                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Email</td>
                <td style="font-weight: normal;"><?php echo e($finalReport->customer_email ?? 'N/A'); ?></td>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Present Address</td>

                <td style="font-weight: normal;"><?php echo e($finalReport->customer_present_address ?? 'N/A'); ?></td>
                </tr>
                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Permanent Address</td>

                <td style="font-weight: normal;"><?php echo e($finalReport->customer_premanent_address ?? 'N/A'); ?></td>

                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Policy No</td>

                <td style="font-weight: normal;"><?php echo e($finalReport->customer_policy_no ?? 'N/A'); ?></td>
                </tr>

                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Policy Start Date</td>
                <td style="font-weight: normal;">
                <?php echo e($finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A'); ?>

                </td>
                
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Policy End Date</td>
                <td style="font-weight: normal;">
                <?php echo e($finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A'); ?>

                </td>
                </tr>
                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Crime Number</td>
                <td style="font-weight: normal;"><?php echo e($finalReport->crime_number ?? 'N/A'); ?></td>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Police Station</td>
                <td style="font-weight: normal;"><?php echo e($finalReport->police_station ?? 'N/A'); ?></td>
                </tr>
                <tr>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Case Type</td>
                <td style="font-weight: normal;"><?php echo e($finalReport->customer_insurance_type ?? 'N/A'); ?></td>
                <td style="border-color: #4b0082;  /* Dark Indigo */
                color: #000000ff;             /* White text */
                padding: 14px 18px;
                text-align: left;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                border: 1px solid #ddd;">Investigation Date</td>
                <td style="font-weight: normal;">
                <?php echo e($finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A'); ?>

                </td>
                </tr>
                </tbody>
                </table>

                </div>

            </div>
            


             <div class="card mb-4">
            <div class="card-body">
        <?php
            $hasData = false;

            $fileExtensions = [
                'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp',
                'mp3', 'wav', 'ogg', 'aac',
                'mp4', 'avi', 'mov', 'mkv', 'webm',
                'pdf', 'doc', 'docx', 'xls', 'xlsx'
            ];
        ?>

        <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }

                if (!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
                    $hasData = true;
                }
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($hasData): ?>
            <div class="card-header bg-success text-white text-center">
                <h3 style="color: #7d18b8; font-weight: bold;">Garage Information</h3>
            </div>

            <table class="table table-bordered table-striped w-100">
            <tbody>
            <?php $rowId = 1; ?>
            <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <tr>
                    <th style="width: 35%; background-color: #f1f1f1; color: #333;">
                        <?php echo e($rowId++); ?>. <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 65%; color: #19191a;">
                        <?php echo e($decodedAnswer); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

            
        <?php else: ?>
    
        <?php endif; ?>
    </div>
</div>


           <?php
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    $hasGarageImages = false;

    foreach ($validQuestions as $question) {
        $column = $question->column_name;
        $answer = $finalReport->$column ?? null;
        $images = [];

        if (!empty($answer) && is_string($answer)) {
            $decoded = json_decode($answer, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $images = $decoded;
            } else {
                $images = [$answer];
            }
        }

        $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            return in_array($ext, $imageExtensions);
        });

        if ($validImages->isNotEmpty()) 
        {
        $hasGarageImages = true;
        break;
        }
    }
?>

        <?php if($hasGarageImages): ?>
        <div class="card mb-4">
        <div class="card-header bg-info text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Garage Uploaded Files</h3>
        </div>
        <div class="card-body">
        <div class="row">
        <?php $__currentLoopData = $validQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $column = $question->column_name;
        $answer = $finalReport->$column ?? null;
        $images = [];

        if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
        }

        $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        return in_array($ext, $imageExtensions);
        });
        ?>

        <?php if($validImages->isNotEmpty()): ?>
        <div class="col-md-12 mb-3">
        <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
        <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                    $imagePath = storage_path('app/public/' . $image);
                ?>

                <?php if(file_exists($imagePath)): ?>
                    <div style="flex: 1 0 21%; box-sizing: border-box;">
                        <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
                                alt="Image"
                                style="width: 70%; height: auto; border: 1px solid #ccc;">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        </div>
        <?php endif; ?>



<!-- Spot -->


           <?php
$hasData = false;
$fileExtensions = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
    'mp3', 'wav', 'ogg', 'aac', // audio
    'mp4', 'avi', 'mov', 'mkv', 'webm', // video
    'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
];

// First loop: check if any valid data exists
foreach ($validQuestions_2 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $ext = '';

    if (!is_null($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded);
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
        } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
        }

        if (trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
            $hasData = true;
            break;
        }
    }
}
?>

<?php if($hasData): ?>
<div class="card mb-4">
    <div class="card-header bg-success text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Spot Informationa</h3>
    </div>
    <div class="card-body">

       <table class="table table-bordered table-striped w-100">
    <tbody>
        <?php $rowId = 1; ?>
        <?php $__currentLoopData = $validQuestions_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <tr>
                    <th style="width: 35%; background-color: #f1f1f1; color: #333;">
                        <?php echo e($rowId++); ?>. <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 65%; color: #19191a;">
                        <?php echo e($decodedAnswer); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


    </div>
</div>
<?php endif; ?>



          <?php
$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
$hasSpotImages = false;

// First, check if there's any valid image
foreach ($validQuestions_2 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $images = [];

    if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
    }

    foreach ($images as $img) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        if (in_array($ext, $imageExtensions)) {
            $imagePath = storage_path('app/public/' . $img);
            if (file_exists($imagePath)) {
                $hasSpotImages = true;
                break 2; // Stop as soon as one valid image is found
            }
        }
    }
}
?>


<?php if($hasSpotImages): ?>
<div class="card mb-4">
    <div class="card-header bg-info text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Spot Uploaded Files</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $validQuestions_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $column = $question->column_name;
                    $answer = $finalReport->$column ?? null;
                    $images = [];

                    if (!empty($answer) && is_string($answer)) {
                        $decoded = json_decode($answer, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                            $images = $decoded;
                        } else {
                            $images = [$answer];
                        }
                    }

                    $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
                        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                        return in_array($ext, $imageExtensions);
                    });
                ?>

                <?php if($validImages->isNotEmpty()): ?>
                    <div class="col-md-12 mb-3">
                        <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
                        <div class="d-flex flex-wrap gap-3 mt-2">
                            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                    $imagePath = storage_path('app/public/' . $image);
                                ?>

                                <?php if(file_exists($imagePath)): ?>
                                    <div style="flex: 1 0 21%; box-sizing: border-box;">
                                        <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
                                            alt="Image"
                                            style="width: 70%; height: auto; border: 1px solid #ccc;">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Driver -->




           <?php
$hasData = false;
$fileExtensions = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
    'mp3', 'wav', 'ogg', 'aac', // audio
    'mp4', 'avi', 'mov', 'mkv', 'webm', // video
    'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
];

// First loop: check if any valid data exists
foreach ($validQuestions_3 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $ext = '';

    if (!is_null($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded);
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
        } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
        }

        if (trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
            $hasData = true;
            break;
        }
    }
}
?>

<?php if($hasData): ?>
<div class="card mb-4">
    <div class="card-header bg-success text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Driver Information </h3>
    </div>
    <div class="card-body">

        <table class="table table-bordered table-striped w-100">
    <tbody>
        <?php $rowId = 1; ?>
        <?php $__currentLoopData = $validQuestions_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <tr>
                    <th style="width: 35%; background-color: #f1f1f1; color: #333;">
                        <?php echo e($rowId++); ?>. <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 65%; color: #19191a;">
                        <?php echo e($decodedAnswer); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    </div>
</div>
<?php endif; ?>



          <?php
$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
$hasSpotImages = false;

// First, check if there's any valid image
foreach ($validQuestions_3 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $images = [];

    if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
    }

    foreach ($images as $img) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        if (in_array($ext, $imageExtensions)) {
            $imagePath = storage_path('app/public/' . $img);
            if (file_exists($imagePath)) {
                $hasSpotImages = true;
                break 2; // Stop as soon as one valid image is found
            }
        }
    }
}
?>


<?php if($hasSpotImages): ?>
<div class="card mb-4">
    <div class="card-header bg-info text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Driver Uploaded Files</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $validQuestions_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $column = $question->column_name;
                    $answer = $finalReport->$column ?? null;
                    $images = [];

                    if (!empty($answer) && is_string($answer)) {
                        $decoded = json_decode($answer, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                            $images = $decoded;
                        } else {
                            $images = [$answer];
                        }
                    }

                    $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
                        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                        return in_array($ext, $imageExtensions);
                    });
                ?>

                <?php if($validImages->isNotEmpty()): ?>
                    <div class="col-md-12 mb-3">
                        <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
                        <div class="d-flex flex-wrap gap-3 mt-2">
                            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                    $imagePath = storage_path('app/public/' . $image);
                                ?>

                                <?php if(file_exists($imagePath)): ?>
                                    <div style="flex: 1 0 21%; box-sizing: border-box;">
                                        <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
                                            alt="Image"
                                            style="width: 70%; height: auto; border: 1px solid #ccc;">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>





<!-- Owner -->

<?php
$hasData = false;
$fileExtensions = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
    'mp3', 'wav', 'ogg', 'aac', // audio
    'mp4', 'avi', 'mov', 'mkv', 'webm', // video
    'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
];

// First loop: check if any valid data exists
foreach ($validQuestions_4 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $ext = '';

    if (!is_null($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded);
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
        } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
        }

        if (trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
            $hasData = true;
            break;
        }
    }
}
?>

<?php if($hasData): ?>
<div class="card mb-4">
    <div class="card-header bg-success text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Owner Information </h3>
    </div>
    <div class="card-body">

       <table class="table table-bordered table-striped w-100">
    <tbody>
        <?php $rowId = 1; ?>
        <?php $__currentLoopData = $validQuestions_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <tr>
                    <th style="width: 35%; background-color: #f1f1f1; color: #333;">
                        <?php echo e($rowId++); ?>. <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 65%; color: #19191a;">
                        <?php echo e($decodedAnswer); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


    </div>
</div>
<?php endif; ?>



          <?php
$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
$hasSpotImages = false;

// First, check if there's any valid image
foreach ($validQuestions_4 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $images = [];

    if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
    }

    foreach ($images as $img) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        if (in_array($ext, $imageExtensions)) {
            $imagePath = storage_path('app/public/' . $img);
            if (file_exists($imagePath)) {
                $hasSpotImages = true;
                break 2; // Stop as soon as one valid image is found
            }
        }
    }
}
?>


<?php if($hasSpotImages): ?>
<div class="card mb-4">
    <div class="card-header bg-info text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Owner Uploaded Files</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $validQuestions_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $column = $question->column_name;
                    $answer = $finalReport->$column ?? null;
                    $images = [];

                    if (!empty($answer) && is_string($answer)) {
                        $decoded = json_decode($answer, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                            $images = $decoded;
                        } else {
                            $images = [$answer];
                        }
                    }

                    $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
                        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                        return in_array($ext, $imageExtensions);
                    });
                ?>

                <?php if($validImages->isNotEmpty()): ?>
                    <div class="col-md-12 mb-3">
                        <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
                        <div class="d-flex flex-wrap gap-3 mt-2">
                            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                                    $imagePath = storage_path('app/public/' . $image);
                                ?>

                                <?php if(file_exists($imagePath)): ?>
                                    <div style="flex: 1 0 21%; box-sizing: border-box;">
                                        <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
                                            alt="Image"
                                            style="width: 70%; height: auto; border: 1px solid #ccc;">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>


<!-- Accident PersonData -->

<?php
$hasData = false;
$fileExtensions = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', // images
    'mp3', 'wav', 'ogg', 'aac', // audio
    'mp4', 'avi', 'mov', 'mkv', 'webm', // video
    'pdf', 'doc', 'docx', 'xls', 'xlsx' // documents
];

// First loop: check if any valid data exists
foreach ($validQuestions_5 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $ext = '';

    if (!is_null($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $decodedAnswer = implode(', ', $decoded);
            $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
        } else {
            $decodedAnswer = $answer;
            $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
        }

        if (trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)) {
            $hasData = true;
            break;
        }
    }
}
?>

<?php if($hasData): ?>
<div class="card mb-4">
    <div class="card-header bg-success text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Accident Person Information </h3>
    </div>
    <div class="card-body">

       <table class="table table-bordered table-striped w-100">
    <tbody>
        <?php $rowId = 1; ?>
        <?php $__currentLoopData = $validQuestions_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column = $question->column_name;
                $answer = $finalReport->$column ?? null;

                $ext = '';
                $decodedAnswer = $answer;

                if (!is_null($answer) && is_string($answer)) {
                    $decoded = json_decode($answer, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $decodedAnswer = implode(', ', $decoded);
                        $ext = strtolower(pathinfo($decoded[0] ?? '', PATHINFO_EXTENSION));
                    } else {
                        $decodedAnswer = $answer;
                        $ext = strtolower(pathinfo($answer, PATHINFO_EXTENSION));
                    }
                }
            ?>

            <?php if(!is_null($decodedAnswer) && trim($decodedAnswer) !== '' && !in_array($ext, $fileExtensions)): ?>
                <tr>
                    <th style="width: 35%; background-color: #f1f1f1; color: #333;">
                        <?php echo e($rowId++); ?>. <?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?>

                    </th>
                    <td style="width: 65%; color: #19191a;">
                        <?php echo e($decodedAnswer); ?>

                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    </div>
</div>
<?php endif; ?>



          <?php
$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
$hasSpotImages = false;

// First, check if there's any valid image
foreach ($validQuestions_5 as $question) {
    $column = $question->column_name;
    $answer = $finalReport->$column ?? null;
    $images = [];

    if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
    }

    foreach ($images as $img) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        if (in_array($ext, $imageExtensions)) {
            $imagePath = storage_path('app/public/' . $img);
            if (file_exists($imagePath)) {
                $hasSpotImages = true;
                break 2; // Stop as soon as one valid image is found
            }
        }
    }
}
?>


        <?php if($hasSpotImages): ?>
        <div class="card mb-4">
        <div class="card-header bg-info text-white text-center">
        <h3 style="color: #7d18b8; font-weight: bold;">Accident Data Uploaded Files</h3>
        </div>
        <div class="card-body">
        <div class="row">
        <?php $__currentLoopData = $validQuestions_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $column = $question->column_name;
        $answer = $finalReport->$column ?? null;
        $images = [];

        if (!empty($answer) && is_string($answer)) {
        $decoded = json_decode($answer, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $images = $decoded;
        } else {
            $images = [$answer];
        }
        }

        $validImages = collect($images)->filter(function ($img) use ($imageExtensions) {
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        return in_array($ext, $imageExtensions);
        });
        ?>

        <?php if($validImages->isNotEmpty()): ?>
        <div class="col-md-12 mb-3">
        <strong><?php echo e($question->question_text ?? ucfirst(str_replace('_', ' ', $column))); ?></strong>
        <div class="d-flex flex-wrap gap-3 mt-2">
            <?php $__currentLoopData = $validImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                    $imagePath = storage_path('app/public/' . $image);
                ?>

                <?php if(file_exists($imagePath)): ?>
                    <div style="flex: 1 0 21%; box-sizing: border-box;">
                        <img src="data:image/<?php echo e($extension); ?>;base64,<?php echo e(base64_encode(file_get_contents($imagePath))); ?>"
                            alt="Image"
                            style="width: 70%; height: auto; border: 1px solid #ccc;">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        </div>
        <?php endif; ?>


            
        <!-- Garage Information Section -->
        <div class="card mb-4">
        <div class="card-header bg-success text-white">
        <h3 style="color: #7d18b8; font-weight: bold;">Executive Information</h3>
        </div>

        <div class="card mb-4">
        <div class="card-body">
        <!-- <div style="margin-bottom: 15px;">
        <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 150px;">Driver Representing Executive:</span>
        <span style="font-size: 16px; color: #19191aff; display: inline-block;"><?php echo e($finalReport->driver_executive ?? 'N/A'); ?></span>
        </div> -->
        <div style="border: 1px solid #ccc; padding: 12px 15px; border-radius: 8px; margin-bottom: 12px; background-color: #f9f9f9;">
    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 200px;">
        Driver Representing Executive
    </span>
    <span style="font-size: 16px; color: #19191aff; display: inline-block;">
        <?php echo e($finalReport->driver_executive ?? 'N/A'); ?>

    </span>
</div>

 <div style="border: 1px solid #ccc; padding: 12px 15px; border-radius: 8px; margin-bottom: 12px; background-color: #f9f9f9;">
    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 200px;">
        Garage Representing Executive
    </span>
    <span style="font-size: 16px; color: #19191aff; display: inline-block;">
        <?php echo e($finalReport->garage_executive ?? 'N/A'); ?>

    </span>
</div>

<div style="border: 1px solid #ccc; padding: 12px 15px; border-radius: 8px; margin-bottom: 12px; background-color: #f9f9f9;">
    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 200px;">
    Spot Representing Executive
    </span>
    <span style="font-size: 16px; color: #19191aff; display: inline-block;">
        <?php echo e($finalReport->spot_executive ?? 'N/A'); ?>

    </span>
</div>

<div style="border: 1px solid #ccc; padding: 12px 15px; border-radius: 8px; margin-bottom: 12px; background-color: #f9f9f9;">
    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 200px;">
   Meeting Representing Executive
    </span>
    <span style="font-size: 16px; color: #19191aff; display: inline-block;">
        <?php echo e($finalReport->owner_executive ?? 'N/A'); ?>

    </span>
</div>

<div style="border: 1px solid #ccc; padding: 12px 15px; border-radius: 8px; margin-bottom: 12px; background-color: #f9f9f9;">
    <span style="font-size: 16px; color: #2C3E50; font-weight: bold; display: inline-block; min-width: 200px;">
  Accident Representing Executive
    </span>
    <span style="font-size: 16px; color: #19191aff; display: inline-block;">
        <?php echo e($finalReport->accident_executive ?? 'N/A'); ?>

    </span>
</div>


        <!-- <div style="margin-bottom: 15px;">
        <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Garage Representing Executive:</span>
        <span style="font-size: 16px; color: #19191aff; display: inline-block;"><?php echo e($finalReport->garage_executive ?? 'N/A'); ?></span>
        </div>
        <div style="margin-bottom: 15px;">
        <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Spot Representing Executive:</span>
        <span style="font-size: 16px; color: #19191aff; display: inline-block;"><?php echo e($finalReport->spot_executive ?? 'N/A'); ?></span>
        </div>
        <div style="margin-bottom: 15px;">
        <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Meeting Representing Executive:</span>
        <span style="font-size: 16px; color: #19191aff; display: inline-block;"><?php echo e($finalReport->owner_executive ?? 'N/A'); ?></span>
        </div>
        <div style="margin-bottom: 15px;">
        <span style="font-size: 16px; color: #2C3E50; font-weight: bold;  display: inline-block; min-width: 150px;">Accident Representing Executive:</span>
        <span style="font-size: 16px; color: #19191aff; display: inline-block;"><?php echo e($finalReport->accident_executive ?? 'N/A'); ?></span>
        </div> -->
        </div>
        </div>

        
        </div>


         <!-- Garage Information Section -->
        <div class="card mb-4">
        <div class="card-header bg-success text-white">
        <h4 style="color: #7d18b8; font-weight: bold;">Submission Date</h4>
        <?php echo e($finalReport->created_at ? \Carbon\Carbon::parse($finalReport->created_at)->format('d-m-Y h:i A') : 'N/A'); ?>

        </div>
        </div>
        </div>

    <!-- Bootstrap JS & Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/pdf/pdf2.blade.php ENDPATH**/ ?>