

<?php $__env->startSection('title', 'Odometer List'); ?>

<?php $__env->startSection('content'); ?>
<!-- <div class="container-fluid">

   <div class="mb-3 d-flex justify-content-between align-items-center">
    <h3 class="fw-bold text-primary mb-0">Odometer List</h3>

    <div>
        <a href="javascript:history.back()" class="btn btn-danger mr-2">
            <i class="fas fa-arrow-left"></i>
        </a>
        <a href="<?php echo e(url()->current()); ?>" class="btn btn-warning">
            <i class="fas fa-sync"></i>
        </a>
    </div>
</div> -->


<div class="container-fluid">
    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-danger mr-2" onclick="window.history.back()" title="Back">
            <i class="fas fa-arrow-left"></i>
        </button>
        <button class="btn btn-warning mr-2" onclick="window.location.reload()" title="Reload">
            <i class="fas fa-sync-alt"></i>
        </button>
     
    </div>

    <div class="card card-primary card-outline shadow-sm">
        <div class="card-header">
    <h3 class="card-title mb-0" style="font-size: 32px;">Odometer List</h3>
        </div>



    <div class="card">
        <div class="card-body">
            <table id="odometerTable" class="table table-bordered table-striped table-hover">
                <thead class="thead-dark text-center">
                    <tr>
                        <th>S.No</th>
                        <th>Name</th>
                        <th>Check In Time</th>
                        <th>Check Out Time</th>
                        <th>Date</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $odometerRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($record->user_name); ?></td>
                            <td><?php echo e($record->check_in_time); ?></td>
                            <td>
                                <?php if($record->check_out_time): ?>
                                    <?php echo e($record->check_out_time); ?>

                                <?php else: ?>
                                    <span class="text-danger font-weight-bold">Exec not closed</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($record->check_out_date): ?>
                                    <?php echo e($record->check_out_date); ?>

                                <?php else: ?>
                                    <span class="text-danger font-weight-bold">Exec not closed</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('odometer.view', $record->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables JS & CSS (can be moved to layout) -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#odometerTable').DataTable({
            "responsive": true,
            "autoWidth": false,
            "ordering": true,
            "pageLength": 10,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "language": {
                "search": "Search all columns:",
                "lengthMenu": "Show _MENU_ records per page",
                "zeroRecords": "No matching records found",
                "info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "No records available",
                "infoFiltered": "(filtered from _MAX_ total records)"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/odometer/index.blade.php ENDPATH**/ ?>