
<?php $__env->startSection('title', 'Report Request'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="d-flex justify-content-end mb-3">
<a href="javascript:history.back()" class="btn btn-danger mr-2">
<i class="fas fa-arrow-left"></i>
</a>
<a href="<?php echo e(url()->current()); ?>" class="btn btn-warning mr-2">
<i class="fas fa-sync-alt"></i>
</a>

</div>

<div class="card card-primary card-outline shadow-sm">
<div class="card-header">
<h3 class="card-title" style="font-size: 32px;">Final Report</h3>
</div>


    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="reportTable" class="table table-bordered table-striped text-center">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Company Name</th>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Download PDF</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($report->customer_name); ?></td>
                            <td><?php echo e($report->company_name); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($report->date)->format('d-m-Y')); ?></td>
                            <td><?php echo e($report->type); ?></td>
                            <td>
                                <a href="javascript:void(0);" onclick="downloadPdf(<?php echo e($report->report_id); ?>)"
                                    class="btn btn-success btn-sm">
                                    <i class="fa fa-download"></i> Download Report
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#reportTable').DataTable({
            responsive: true,
            autoWidth: false,
            pageLength: 10,
            ordering: true,
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                zeroRecords: "No matching reports found",
                info: "Showing _START_ to _END_ of _TOTAL_ reports",
                infoEmpty: "No reports available",
                infoFiltered: "(filtered from _MAX_ total entries)"
            }
        });
    });

    function downloadPdf(id) {
        if (id != null) {
            $.ajax({
                url: '<?php echo e(route("final.report.download")); ?>',
                type: 'POST',
                data: {
                    report_id: id,
                    _token: '<?php echo e(csrf_token()); ?>',
                },
                xhrFields: {
                    responseType: 'blob'
                },
                success: function (response) {
                    if (response instanceof Blob) {
                        var link = document.createElement('a');
                        link.href = URL.createObjectURL(response);
                        link.download = 'report_' + id + '.pdf';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        alert("Report could not be downloaded.");
                    }
                },
                error: function (xhr, status, error) {
                    alert('Error: ' + error + '\n' + xhr.responseText);
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/final-report/index.blade.php ENDPATH**/ ?>