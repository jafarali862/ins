<div class="container-fluid">
    <div class="row">
        <!-- Left Column -->
        <div class="col-md-6">
            <h5>Customer Name:</h5>
            <p><?php echo e($customers->name); ?> (<?php echo e($customers->phone); ?>)</p>

            <h5>Company:</h5>
            <p><?php echo e($customers->custname); ?></p>

            <h5>Crime Number:</h5>
            <p><?php echo e($customers->crime_number); ?></p>

            <h5>Police Station:</h5>
            <p><?php echo e($customers->police_station); ?></p>

              <h5>Executive Name:</h5>
            <p><b>Driver</b>: <?php echo e($customers->driver_name); ?> </p>
            <p><b>Garage</b>: <?php echo e($customers->garage_name); ?> </p>
            <p><b>Spot</b>: <?php echo e($customers->spot_name); ?> </p>
            <p><b>Meeting</b>: <?php echo e($customers->meeting_name); ?> </p>
            <p><b>Accident</b>: <?php echo e($customers->accident_name); ?> </p>
        </div>

        <!-- Right Column -->
        <div class="col-md-6">
            <h5>Assign Date:</h5>
            <p><?php echo e(\Carbon\Carbon::parse($customers->created_at)->format('d-m-Y')); ?></p>

            <h5>Status:</h5>
            <p>
                <?php if($customers->case_status == 1): ?>
                    <span class="badge bg-danger">Pending</span>
                <?php elseif($customers->case_status == 0): ?>
                    <span class="badge bg-success">Complete</span>
                <?php elseif($customers->case_status == 2): ?>
                    <span class="badge bg-warning">Assigned</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Unknown</span>
                <?php endif; ?>
            </p>

             <h5>Investigation Date:</h5>
            <p><?php echo e(\Carbon\Carbon::parse($customers->case_date)->format('d-m-Y')); ?></p>


             <h5>Case Type:</h5>
            <p><?php echo e($customers->insurance_type); ?> </p>


           


            
        </div>
    </div>
</div>
<?php /**PATH C:\Users\user\Pictures\adminlte-laravel10-main\resources\views/dashboard/case/view.blade.php ENDPATH**/ ?>