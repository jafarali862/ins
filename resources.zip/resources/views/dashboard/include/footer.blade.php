<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        <!-- Optional: Any extra message or version info -->
        Powered by Niveosys
    </div>
    <strong>
        &copy; {{ date('Y') }} 
        <a href="https://niveosys.com" target="_blank">Niveosys Technologies Pvt Ltd</a>.
    </strong> All rights reserved.
</footer>
