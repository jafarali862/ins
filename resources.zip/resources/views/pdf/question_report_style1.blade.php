<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; font-size: 14px; }
        .question { margin-bottom: 20px; }
        .label { font-weight: bold; }
    </style>
</head>
<body>
    <div class="question">
        <div class="label">Question:</div>
        <div>{{ $question->question }}</div>
    </div>
    <div class="label">Answer (text): ____________________________</div>

    <div class="row">

    <div class="col-md-6">
        <h4>Test checking</h4>
    </div>

     <div class="col-md-6">
        <h4>Test checking data is done.............</h4>
    </div>



    </div>
</body>
</html>
