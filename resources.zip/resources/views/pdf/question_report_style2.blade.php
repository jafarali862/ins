<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; font-size: 13px; }
        .label { font-weight: bold; }
        textarea { width: 100%; height: 150px; margin-top: 5px; }
    </style>
</head>
<body>
    <p class="label">Question:</p>
    <p>{{ $question->question }}</p>
    <p class="label">Your Answer:</p>
    <textarea></textarea>



     <div class="row">

    <div class="col-md-6">
        <h4>Hello</h4>
    </div>

     <div class="col-md-6">
        <h4>dddddddddd</h4>
    </div>



    </div>


</body>
</html>
