@error($slot)
    <span class="text-danger">{{ $message }}</span>
@enderror